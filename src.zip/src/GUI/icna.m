function icna
%DEPRECATED. ICNA main menu
%
% icna - Displays ICNNA's main menu
%
%
% This function is now DEPRECATED. Use function guiICNNA instead.
%
%
% Copyright 2008-23
% @author Felipe Orihuela-Espina
%
% See also guiAnalysis, guiExperiment, guiExperimentSpace
%



%% Log
%
% File created: 6-Oct-2008
% File last modified (before creation of this log): 25-Apr-2018
%
% 25-Apr-2018: FOE. Deprecated. Substituted for function icnna.
%
% 14-May-2018: FOE. Deprecated. Substituted for function guiICNNA.
%


warning('ICNNA:GUI:icna',...
        'This function is now deprecated. Please use guiICNNA function instead.');
guiICNNA

end