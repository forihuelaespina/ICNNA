%Upgrading ICNA class and object structure to newer version
%
% Experiment files generated with old versions of ICNA will not
%be compatible with the newer structures. This script aims at
%upgrading those structures so that the experiment object can still
%be used.
%
% 5-May-2015: In particular, I have run this script for
%the Decision Making experiment. The new upgraded dataset was
%saved to file:
%   ../NIRS/experimentalData/DM/icna_DM_updatedToNewICNAObjectStructure.mat'
%
%
% 6-May-2015: The original file icna_DM wrogly encodes many DEF stimuli
%group as ABC stimuli. The "icna_DMrecoded" fixes these errors. I have
%now run this script for the recoded version of the
%Decision Making experiment. The new upgraded dataset was
%saved to file:
%   ../NIRS/experimentalData/DM/icna_DMrecoded_updatedToNewICNAObjectStructure.mat'
%
% also I have run it in the integrity checked version of it, and
%saved to:
%   ../NIRS/experimentalData/DM/icna_DMrecoded_integrityNoOptMov_updatedToNewICNAObjectStructure.mat'
%
%
% Copyright 2015
% @date: 5-May-2015
% @author: Felipe Orihuela-Espina
% @modified: 6-May-2015

subjects=getSubjectList(dataset);
for subjID=subjects
    subj=getSubject(dataset,subjID);
    sessions=getSessionList(subj);
for sessID=sessions
    %Get session Task (2)
    sess=getSession(subj,sessID);
    ds=getDataSource(sess,1);
    sd=getStructuredData(ds,get(ds,'ActiveStructured'));
    oldt=get(sd,'Timeline');
        %Old format lacks eventsInfo
    %Convert to new format
    t=timeline(get(oldt,'Length'));
    nConds=get(oldt,'NConditions');
    for cc=1:nConds
        tag=getConditionTag(oldt,cc);
        %cevents=getConditionEvents(old_t,tag);
        cevents=silly(oldt,tag);
            %The "method" silly is just a copy and paste from method
            %getConditionEvents(old_t,tag) where the line accesing the
            %eventsInfo has been commented.
            %To avoid making a mess I have removed this "method" silly
            %after running this.
        t=addCondition(t,tag,cevents);
    end
    %t
    %"copy" to a new timeline so it reads "older" format
    %guiTimeline(t);
    %waitfor(gcf);
    
    %Also add a channel location map
    clm=channelLocationMap();
    clm=set(clm,'nChannels',get(sd,'NChannels'));
    sd=set(sd,'ChannelLocationMap',clm);
    sd=set(sd,'Timeline',t);
    ds=setStructuredData(ds,get(ds,'ActiveStructured'),sd);
    sess=setDataSource(sess,1,ds);
    subj=setSession(subj,sessID,sess);
end
    dataset=setSubject(dataset,subjID,subj);
end

