function [status]=icnna_releaseVersion(v)
%Release a new version of ICNNA
%
% [status]=icnna_releaseVersion(v) Release a new version 'v' of ICNNA, e.g.
%
%       icnna_releaseVersion('1.2.2');
%
%Generates a .zip file named ICNNAvX.X.X where X.X.X is the
%version being released. The .zip file contains a ready to
%unzip conpy of all files to run the latest version of
%ICNA.
%
%For additional information about ICNNA please refer to
%the included documentation.
%
%% REMARKS
%
% This function creates (and hopefully removes) a temporal
%folder, and may require some disk space.
%
%% Parameters
%
% v - A string representing the new version to be released.
%
%% Output
%
% status -  Return a 1 if successful and 0 if unsuccessfull.
%
% Generates a .zip file named ICNNAvX.X.X where X.X.X is the
%version being released.
% 
%
%
% Copyright 2010-24
% @author Felipe Orihuela-Espina
% 
% See also guiICNNA
%

%% Log
%
%
% File created: 5-Jan-2010
% File last modified (before creation of this log): 25-Apr-2018
%
% 25-Apr-2018: FOE. 
%   + Renamed icnna_releaseVersion. Output file is now ICNNA....
%     Added new class rawData_NIRScout y new function mbll
%
% 24-Mar-2014: FOE. 
%   + Updated export of the registration tool
%
% 13-Oct-2013: FOE. 
%   + Added ourput of files:
%       + miscellaneous/import_ETG4000_3DChannelPosition.m
%
% 30-Oct-2019: FOE. 
%   + ICNNA startup script updated.
%
% 13-Jan-2022: FOE. 
%   + Updated userguide filename and documentation folder
%
% 18-Jul-2023: FOE. 
%   + Got rid of the old labels @date and @modified.
%   + Added support to copy the packages folder.
%   + paths now use filesep instead of explcit '/' or '\'
%
% 18-Jul-2023: FOE.
%   + Bug fixed: v1.2.0 packaging did not include the @rawData_Snirf class.
%
% 8-May-2024: FOE.
%   + Added copying the HR tool.
%   + Revisited the zipping and cleaning step
%   + The new version is directly put into the stable versions folder
%

opt.verbose = true;
opt.incRegistrationTool = true;
opt.incHRTool = true;

%status = 1;
%Basically copy all necessary files, and zip them.
stableFolder = ['..' filesep 'stable' filesep];
tempFolder = [stableFolder 'ICNNAv' v filesep];
docFolder = ['doc' filesep];
objectsFolder = ['oo' filesep];
guiFolder = ['GUI' filesep];
pkgsFolder = ['+icnna' filesep];
HRtoolFolder = ['HR' filesep];

%% Replicate the structure
if opt.verbose
    disp([datestr(now,13) ': Generating temporary folder structure...']);
end
[status,message,messageid] = mkdir(['.' filesep],tempFolder);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = mkdir(tempFolder,objectsFolder);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = mkdir(tempFolder,docFolder);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = mkdir(tempFolder,guiFolder);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = mkdir(tempFolder,[guiFolder 'icons' filesep]);
if status==0, disp([messageid ': ' message]); return; end
%For the packages folder I only need to create the top folder as copyfile
%will later take care of the rest
[status,message,messageid] = mkdir(tempFolder,pkgsFolder);    
if status==0, disp([messageid ': ' message]); return; end

[status,message,messageid] = mkdir(tempFolder,['miscellaneous' filesep]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = mkdir(tempFolder,['plotting' filesep]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = mkdir(tempFolder,['util' filesep]);
if status==0, disp([messageid ': ' message]); return; end

%Copy objects of interest directly
%%%Note that copyfile also copies folders.
if opt.verbose
    disp([datestr(now,13) ': Copying objects...']);
end
[status,message,messageid] = ...
    copyfile(['.' filesep objectsFolder '@analysis'], ...
             [tempFolder objectsFolder '@analysis']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@channelLocationMap'], ...
             [tempFolder objectsFolder '@channelLocationMap']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@cluster'], ...
             [tempFolder objectsFolder '@cluster']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@dataSource'], ...
             [tempFolder objectsFolder '@dataSource']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@dataSourceDefinition'], ...
             [tempFolder objectsFolder '@dataSourceDefinition']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@experiment'], ...
             [tempFolder objectsFolder '@experiment']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@experimentSpace'], ...
             [tempFolder objectsFolder '@experimentSpace']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@integrityStatus'], ...
             [tempFolder objectsFolder '@integrityStatus']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@logarithmicRadialGrid'], ...
             [tempFolder objectsFolder '@logarithmicRadialGrid']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@menaGrid'], ...
             [tempFolder objectsFolder '@menaGrid']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@neuroimage'], ...
             [tempFolder objectsFolder '@neuroimage']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@nirs_neuroimage'], ...
             [tempFolder objectsFolder '@nirs_neuroimage']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@rawData'], ...
             [tempFolder objectsFolder '@rawData']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@rawData_ETG4000'], ...
             [tempFolder objectsFolder '@rawData_ETG4000']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@rawData_NIRScout'], ...
             [tempFolder objectsFolder '@rawData_NIRScout']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@rawData_Snirf'], ...
             [tempFolder objectsFolder '@rawData_Snirf']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@session'], ...
             [tempFolder objectsFolder '@session']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@sessionDefinition'], ...
             [tempFolder objectsFolder '@sessionDefinition']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@structuredData'], ...
             [tempFolder objectsFolder '@structuredData']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@subject'], ...
             [tempFolder objectsFolder '@subject']);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] =  ...
    copyfile(['.' filesep objectsFolder '@timeline'], ...
             [tempFolder objectsFolder '@timeline']);
if status==0, disp([messageid ': ' message]); return; end

%% Copy all other necessary files
if opt.verbose
    disp([datestr(now,13) ': Copying startup script ...']);
end
[status,message,messageid] = copyfile(['.' filesep 'icnna_startup.m'], ...
                                     tempFolder);
if status==0, disp([messageid ': ' message]); return; end

if opt.verbose
    disp([datestr(now,13) ': Copying documentation ...']);
end
[status,message,messageid] = copyfile(['..' filesep 'doc' filesep 'ICNNA_UserGuide.pdf'], ...
                                     [tempFolder docFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['..' filesep 'doc' filesep 'ICNNA-Version.log'], ...
                                     [tempFolder docFolder]);
if status==0, disp([messageid ': ' message]); return; end

if opt.verbose
    disp([datestr(now,13) ': Copying GUI files ...']);
end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'aboutICNNA.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiAnalysis.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiBasicVisualization.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiCheckIntegrity.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiManualIntegrity.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiCluster.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiDataSource.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiDataSourceDefinition.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiExperiment.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiExperimentSpace.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiMenaGrid.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiSession.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiSessionDefinition.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiSubject.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiTimeline.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiVisualizeAnalysis.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiVisualizeEMDAnalysis.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'icna.m'], ...
                                     [tempFolder guiFolder]); %DEPRECATED file
if status==0, disp([messageid ': ' message]); return; end
% [status,message,messageid] = copyfile(['.' filesep guiFolder 'icnna.m'], ...
%                                      [tempFolder guiFolder]);
% if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'guiICNNA.m'], ...
                                     [tempFolder guiFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'icons' filesep '*.mat'], ...
                                     [tempFolder guiFolder 'icons' filesep]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep guiFolder 'icons' filesep 'ICNNA_jack.jpg'], ...
                                     [tempFolder guiFolder 'icons' filesep]);
if status==0, disp([messageid ': ' message]); return; end

if opt.incRegistrationTool
    [status,message,messageid] = copyfile(['.' filesep guiFolder 'guiRegistration.m'], ...
                                     [tempFolder guiFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    [status,message,messageid] = copyfile(['.' filesep guiFolder 'guiRegistrationOptions.m'], ...
                                     [tempFolder guiFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    [status,message,messageid] = copyfile(['.' filesep guiFolder 'registration_loadAppOptions.m'], ...
                                     [tempFolder guiFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    [status,message,messageid] = copyfile(['.' filesep guiFolder 'aboutRegistration.m'], ...
                                     [tempFolder guiFolder]);
    if status==0, disp([messageid ': ' message]); return; end
end


if opt.verbose
    disp([datestr(now,13) ': Copying miscellaneous files ...']);
end
miscFolder = ['miscellaneous' filesep];
[status,message,messageid] = copyfile(['.' filesep miscFolder 'activityMatrix2xls.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' batchBasicVisualization.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'batchBasicVisualization.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' batchBasicVisualization.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'blockResample.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' blockResample.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'blocksTemporalAverage.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' blocksTemporalAverage.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'calculateHaemodynamics.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' calculateHaemodynamics.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'gammaR.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' gammaR.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'gammaT.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' gammaT.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'generateDB_withBreak.m'], ...
                                     [tempFolder miscFolder]);                            
if status==0, disp([messageid ': ' message ' generateDB_withBreak.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'generateDBHelpFile.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' generateDBHelpFile.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'getActivityMatrix.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' getActivityMatrix.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'getActivityMatrixPerRecording.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' getActivityMatrixPerRecording.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'getAverageSD.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' getAverageSD.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'getDBConstants.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' getDBConstants.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'getIntegrityReport.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' getIntegrityReport.m']); return; end
%==== Graph theory routines
[status,message,messageid] = copyfile(['.' filesep miscFolder 'getConnectivity.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' getConnectivity.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'graph_*.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' graph_*.m']); return; end
%==========================
[status,message,messageid] = copyfile(['.' filesep miscFolder 'import_ETG4000_3DChannelPosition.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' importfOSAfile.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'importfOSAfile.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' importfOSAfile.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'mbll.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' mbll.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'runIntegrity.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' runIntegrity.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'runIntegrityOnRaw.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' snirfUnfoldMeasurementList.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'snirfUnfoldMeasurementList.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' runIntegrityOnRaw.m']); return; end
[status,message,messageid] = copyfile(['.' filesep miscFolder 'unfoldExperiment.m'], ...
                                     [tempFolder miscFolder]);
if status==0, disp([messageid ': ' message ' unfoldExperiment.m']); return; end



if opt.incRegistrationTool
    [status,message,messageid] = copyfile(['.' filesep miscFolder 'generatePositioningSystemMesh.m'], ...
                                     [tempFolder miscFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    [status,message,messageid] = copyfile(['.' filesep miscFolder 'generateRegistrationMesh.m'], ...
                                     [tempFolder miscFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    [status,message,messageid] = copyfile(['.' filesep miscFolder 'mesh3D_*.m'], ...
                                     [tempFolder miscFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    [status,message,messageid] = copyfile(['.' filesep miscFolder 'registration_*.m'], ...
                                     [tempFolder miscFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    %Deprecated methods
    [status,message,messageid] = copyfile(['.' filesep miscFolder 'generateOptodePositioningSystemGrid.m'], ...
                                     [tempFolder miscFolder]);
    if status==0, disp([messageid ': ' message]); return; end
    [status,message,messageid] = copyfile(['.' filesep miscFolder 'optodeSpace_*.m'], ...
                                     [tempFolder miscFolder]);
    if status==0, disp([messageid ': ' message]); return; end
end


if opt.verbose
    disp([datestr(now,13) ': Copying plotting files ...']);
end
plotFolder = ['plotting' filesep];
[status,message,messageid] = copyfile(['.' filesep plotFolder 'circle.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' circle.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'plotChannel.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' plotChannel.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'plotCluster2D.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' plotCluster2D.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'plotCluster3D.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' plotCluster3D.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'plotDyDx.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' plotDyDx.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'plotStructuredData.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message 'plotStructureData.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'plotTopo.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' plotTopo.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'rotateTickLabel.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' rotateTickLabel.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'shadeTimeline.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' shadeTimeline.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'suplabel.m'], ...
                                     [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' suplabel.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'topoOnHead.m'], ...
                                    [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' topoOnHead.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'topoOptodeArray.m'], ...
                                    [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' topoOptodeArray.m']); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'topoOptodeArray.m'], ...
                                    [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message ' topoOptodeArray.m']); return; end

[status,message,messageid] = copyfile(['.' filesep plotFolder '*.tif'], ...
                                    [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message]); return; end
[status,message,messageid] = copyfile(['.' filesep plotFolder 'fNIRSColorMapHitachi.mat'], ...
                                    [tempFolder plotFolder]);
if status==0, disp([messageid ': ' message]); return; end


if opt.incRegistrationTool
    [status,message,messageid] = copyfile(['.' filesep plotFolder 'optodeSpace_*.m'], ...
                                     [tempFolder plotFolder]);
    if status==0, disp([messageid ': ' message]); return; end
end


if opt.verbose
    disp([datestr(now,13) ': Copying util files ...']);
end
utilFolder = ['util' filesep];
[status,message,messageid] = copyfile(['.' filesep utilFolder '*.m'], ...
                                     [tempFolder utilFolder]);
if status==0, disp([messageid ': ' message]); return; end




if opt.verbose
    disp([datestr(now,13) ': Copying packages ...']);
end
[status,message,messageid] = copyfile(['.' filesep pkgsFolder], ...
                                      [tempFolder pkgsFolder]);
if status==0, disp([messageid ': ' message]); return; end



if opt.incHRTool
    if opt.verbose
        disp([datestr(now,13) ': Copying HR tool...']);
    end
    [status,message,messageid] = copyfile(['.' filesep HRtoolFolder], ...
                                          [tempFolder HRtoolFolder]);
    if status==0, disp([messageid ': ' message]); return; end
end






%% Now zip
if opt.verbose
    disp([datestr(now,13) ': Zipping ...']);
end
zip([stableFolder 'ICNNAv' v '.zip'],tempFolder);

%% Remove temporary folder
if opt.verbose
    disp([datestr(now,13) ': Deleting temporary files ...']);
end
[status,message,messageid] = rmdir(tempFolder,'s');
if status==0, disp([messageid message]); return; end




if opt.verbose
    disp([datestr(now,13) ': Done ...']);
end



end
