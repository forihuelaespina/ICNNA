% @RAWDATA_LSL
%
% Files
%   convert                 - RAWDATA_LSL/CONVERT Convert raw LSL data stream to a structuredData
%   display                 - RAWDATA_LSL/DISPLAY Command window display
%   eq                      - RAWDATA_LSL/EQ Compares two objects.
%   get                     - RAWDATA_LSL/GET Get properties from the specified object
%   getStream               - RAWDATA_LSL/GETSTREAM Gets the k-th stream raw data
%   import                  - RAWDATA_LSL/IMPORT Reads the stream data
%   rawData_LSL             - Class rawData_LSL
%   set                     - RAWDATA_LSL/SET Set object properties and return the updated object
