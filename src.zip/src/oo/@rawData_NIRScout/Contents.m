% @RAWDATA_NIRScout
%
% Files
%   convert         - Convert raw light intensities to a neuroimage
%   display         - Command window display of a rawData_NIRScout
%   eq              - Compares two objects.
%   get             - Get properties from the specified object
%   import          - Reads the raw light intensities 
%   rawData_NIRScout - Class rawData_NIRScout
%   set             - Set object properties and return the updated object
%   table_abscoeff  - _____________________________________________________________________________________________
