function B=rgb2cmyk(varargin)
%Converts an RGB image to an CMYK image
%
% B=rgb2cmyk(A) Converts the RGB image A (size MxNx3) to an CMYK
%   image B (size MxNx4). B can be saved to a file using MATLAB's
%   function imwrite.
%
% B=rgb2cmyk(filename) Converts the RGB image in filename to an CMYK
%   image B (size MxNx4). B can be saved to a file using MATLAB's
%   function imwrite.
%
% B=rgb2cmyk(...,outfilename) Converts the RGB image
%   to an CMYK image B (size MxNx4) and saves it to file outfilename
%   in tif format (uncompressed, 300 dpi), common for journal
%   publication.
%
%
%
% Copyright 2009
% Author: Felipe Orihuela-Espina
% Date: 21-Oct-2009
%
% See also
%

%Read the image
if ischar(varargin{1})
    filename=varargin{1};
    A=imread(filename);
else
    A=varargin{1};
end
varargin(1)=[];

%Convert the image
B=im_rgb2cmyk(A); %see core function below

%Write the image if necessary
if ~isempty(varargin)
    outfilename=varargin{1};
    imwrite(B,outfilename,'tif',...
            'Compression','none','Resolution',[300 300]);
end





function B=im_rgb2cmyk (A)
% B=im_rgb2cymk(A) Converts the RGB image A (size MxNx3) to an CMYK
%   image B (size MxNx4).
%
%CONVERSION CODE MODIFIED FROM SOURCE:
%http://www.javascripter.net/faq/rgb2cmyk.htm
    
 r=A(:,:,1);
 g=A(:,:,2);
 b=A(:,:,3);
 
if (any(any(r<0)) || any(any(g<0)) || any(any(b<0)) ...
  || any(any(r>255)) || any(any(g>255)) || any(any(b>255)))
   error ('RGB values must be in the range 0 to 255.');
end

 computedC = 1 - (double(r)/255); %DO NOT REMOVE THE CONVERSION TO DOUBLE
 computedM = 1 - (double(g)/255);
 computedY = 1 - (double(b)/255);

 minCMY = min(computedC,min(computedM,computedY));
 
 computedC = (computedC - minCMY) ./ (1 - minCMY) ;
 computedM = (computedM - minCMY) ./ (1 - minCMY) ;
 computedY = (computedY - minCMY) ./ (1 - minCMY) ;
 computedK = minCMY;

 B(:,:,1) = computedC;
 B(:,:,2) = computedM;
 B(:,:,3) = computedY;
 B(:,:,4) = computedK;
 
%  %%BLACK / THIS CONVERSION TO BLACK LEADS TO SOME ERRORS...
%  %%BUT THE CONVERSION SEEMS TO WORK WITHOUT IT.
%  idxBlack=find(r==0 & g==0 & b==0);
%  height=size(A,1);
%  width=size(A,2);
%  [idxBlackX,idxBlackY] = ind2sub([height width],idxBlack);
%  B(idxBlackX,idxBlackY,1) = 0;
%  B(idxBlackX,idxBlackY,2) = 0;
%  B(idxBlackX,idxBlackY,3) = 0;
%  B(idxBlackX,idxBlackY,4) = 1;
 
end

end
