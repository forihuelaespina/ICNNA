function display(obj)
%TIMELINE/DISPLAY Command window display of a timeline
%
%Produce a string representation of the object, which is
%then displayed on the with an output similar to the standard
%MATLAB output.
%
% Copyright 2008
% @date: 18-Apr-2008
% @author Felipe Orihuela-Espina
%
% See also timeline, get, set
%

disp(' ');
disp([inputname(1),'= ']);
disp(['   length: ' num2str(obj.length)]);
disp('   Exclusory State: ');
disp(mat2str(obj.exclusory));
if isempty(obj.conditions)
    disp('   conditions: {}'); 
else
    nConditions=length(obj.conditions);
    disp(['   Conditions: ' num2str(nConditions)]); 
    for ii=1:nConditions
        disp(['=== Condition ''' obj.conditions{ii}.tag '''']);
        cevents=obj.conditions{ii}.events;
        if (isempty(cevents))
            disp('   No events defined for this condition.');
        else
            disp('   Onsets/Durations');
            disp(cevents);
        end
    end
end
disp(' ');
