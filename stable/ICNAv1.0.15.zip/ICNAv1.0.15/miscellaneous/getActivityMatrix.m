function [M,hFig,Im]=getActivityMatrix(db,options)
%Computes and plot the channel (significant) activation matrix
%
% [M,hFig,Im]=getActivityMatrix(db,options) computes
%   and plot the channel (significant) activation matrix
%
%Similar to function getActivityMatrixPerrecording channel
%(significant) activation matrix is generated. However rather
%than producing a row per recording i.e., averaged only across
%blocks, this function yields a row per <session,stimulus>
%averaging across subjects, datasources and blocks.
%
%
%
%% The database structure
%
% The database parameter is a database that can be obtained from ICNA.
%This database has the following colums
%
% 1 - COL_SUBJECT
% 2 - COL_SESSION
% 3 - COL_DATASOURCE
% 4 - COL_STRUCTUREDDATA
% 5 - COL_CHANNEL
% 6 - COL_SIGNAL of which signal Oxy is coded as 1 and deoxy is coded as 2
% 7 - COL_STIMULUS
% 8 - COL_BLOCK
% 
% 9 - COL_MEAN_BASELINE
% 10 - COL_STD_BASELINE
% 11 - COL_MEAN_TASK
% 12 - COL_STD_TASK
% 13 - COL_TASK_MINUS_BASELINE
% 14 - COL_AREA_UNDER_CURVE_TASK
%
%
% See function generateDB_withBreak for further information.
%
%% The activity patterns
%
%
% 16 activity patterns can be distinguish in total:
%
%   HbO2\HHb | ++| + | - | --|
%      ------+---+---+---+---+
%         ++ | 1 | 2 | 3 | 4 |
%      ------+---+---+---+---+
%          + | 5 | 6 | 7 | 8 |
%      ------+---+---+---+---+
%          - | 9 | 10| 11| 12|
%      ------+---+---+---+---+
%         -- | 13| 14| 15| 16|
%      ------+---+---+---+---+
%
%  ++ - Increment reached statistical significance
%   + - Increment did not reach statistical significance
%   - - Decrement did not reach statistical significance
%  -- - Decrement reached statistical significance
%
%
% Thus:
%  + Pattern 4 is classical activation
%  + Pattern 13 is classical deactivation
%
%
%In addition a pattern 17 identifies missing data.
%
%
%% Parameter
%
% db - a database as obtained from ICNA with the follwoing columns:
%
%
%
% options - An struct of options
%   .fontSize - Font size to be used in the figure series
%   .destinationFolder - Destination folder. Default value is
%       './images/'
%   .outputFilename - OutputFilename WITHOUT EXTENSION.Default
%       value is
%       'ActivityMatrixBySession_<TestName>'
%   .save - True if you want the figure to be saved. False (default)
%       otherwise. Figures are saved in MATLAB .fig format and in
%       .tif format non-compressed at 300dpi.
%   .sessionLabels - A cell array with the session labels. By default
%       is set to {'Control','Stimulus'} if there are two sessions
%       or {'Session 1',...,'Session N'} for more than 2 sessions
%   .significanceLevel -  Perform statistical tests at the indicated
%       significance level. Default values is 0.05 i.e. alpha=5% (p<0.05)
%   .stimulusLabels - A cell array with the stimulus labels. By default
%       is set to {'A'} if there is only one stimulus
%       or {'A','B',...} for more than one stimulus.
%
%
%% Output
%
% M - The activity matrix
%
% hFig - Handle to the activity matrix figure
%
% Im - Index to the activity matrix, with the follwoing columns
%   <Subject, Session, DataSource, Stimulus>. This is to keep
%   compatibility with function getActivityMatrixPerRecording,
%   however Subject and DataSource will always be set to 1 in
%   this case.
%
%
%
% Copyright 2009-11
% @date: 11-Jan-2009
% @author: Felipe Orihuela-Espina
% @modified: 26-Jul-2011
%
% See also experimentSpace, getActivityMatrixPerRecording,
%   generateDB_withBreak
%

internalOpt_Test='SingRank';
%internalOpt_Test='ttest2';

%% Deal with options
opt.save=false;
opt.destinationFolder='./images/';
opt.outputFilename=['ActivityMatrixBySession_' internalOpt_Test];
%opt.mainTitle='';
opt.fontSize=13;
opt.significanceLevel = 0.05;
opt.sessionTags={'Control','Stimulus'};
% opt.sessionTags={'Controla','Controlb','Controlc',...
%             'Controld','Controle','Controlf',...
%             'GCMCa','GCMCb','GCMCc',...
%             'GCMCd','GCMCe','GCMCf'};
sessionLabelsProvided=false;
%Session 1: Without GCMC feedback (Control)
%Session 2: With GCMC feedback
%sessionLabels={'Size No Matter','Size Matter'};
opt.stimulusTags={'A'};
%stimulusLabels={'A','B','Shadow','No Shadow'};
stimulusLabelsProvided=false;
if exist('options','var')
    if isfield(options,'save')
        opt.save=options.save;
    end
    if isfield(options,'destinationFolder')
        opt.destinationFolder=options.destinationFolder;
    end
    if isfield(options,'significanceLevel')
        opt.significanceLevel=options.significanceLevel;
        opt.outputFilename=[opt.outputFilename ...
                            '_p' num2str(opt.significanceLevel)];
    end
    if isfield(options,'outputFilename')
        opt.outputFilename=options.outputFilename;
    end
    if isfield(options,'fontSize')
        opt.fontSize=options.fontSize;
    end
    if isfield(options,'sessionLabels')
        opt.sessionTags=options.sessionLabels;
        sessionLabelsProvided=true;
    end
    if isfield(options,'stimulusLabels')
        opt.stimulusTags=options.stimulusLabels;
        stimulusLabelsProvided=true;
    end
end

%Some constants to make my life easier:
[dbCons,~]=getDBConstants;
% COL_SUBJECT = 1;
% COL_SESSION = 2;
% COL_DATASOURCE = 3;
% COL_STRUCTUREDDATA = 4;
% COL_CHANNEL = 5;
% COL_SIGNAL = 6;
% COL_STIMULUS = 7;
% COL_BLOCK = 8;
% 
% COL_MEAN_BASELINE = 9;
% COL_STD_BASELINE = 10;
% COL_MEAN_TASK = 11;
% COL_STD_TASK = 12;
% COL_TASK_MINUS_BASELINE = 13;
% COL_AREA_UNDER_CURVE_TASK = 14;


OXY=1;
DEOXY=2;


nSessions = max(db(:,dbCons.COL_SESSION));
nStimulus = max(db(:,dbCons.COL_STIMULUS));
nChannels = max(db(:,dbCons.COL_CHANNEL));
M=zeros(0,nChannels);

if ~sessionLabelsProvided
    %Need to regenerate the session tags so there
    %are as many tags as sessions
    if nSessions ~=2
        opt.sessionTags=cell(1,nSessions);
        for ss=1:nSessions
            opt.sessionTags(ss)={['Sess. ' num2str(ss)]};
        end
    end
end
if ~stimulusLabelsProvided
    %Need to regenerate the stimulus tags so there
    %are as many tags as stimulus
    if nStimulus ~=1
        opt.stimulusTags=cell(1,nStimulus);
        for ss=1:nStimulus
            tmpPrefix = floor((ss-1)/26);
            s='';
            if tmpPrefix ~=0, s=char(64+tmpPrefix); end;
            tmpss = mod(ss,26);
            if tmpss ==0,
                s=[s 'Z'];
            else
                s=[s char(64+tmpss)];
            end;
            opt.stimulusTags(ss)={s};
        end
    end
end

sessLabels=cell(0,1);
Im=zeros(0,4);

for sess=1:nSessions
  for stim=1:nStimulus
    chActivity_Sign=nan(2,nChannels);
    chActivity_pValue=nan(2,nChannels);
    for ch=1:nChannels
        idx = find(db(:,dbCons.COL_SESSION) == sess ...
                 & db(:,dbCons.COL_STIMULUS) == stim ...
                 & db(:,dbCons.COL_CHANNEL) == ch ...
                 & db(:,dbCons.COL_SIGNAL) == OXY);
        %Some info may be missing due to integrity
        if ~isempty(idx)
            tmpDB = db(idx,:);
            oxy_Sign = sign(mean(tmpDB(:,dbCons.COL_MEAN_TASK)...
                -tmpDB(:,dbCons.COL_MEAN_BASELINE)));
            switch (internalOpt_Test)
                case 'SingRank'
                    oxy_pValue = signrank(tmpDB(:,dbCons.COL_MEAN_TASK),...
                        tmpDB(:,dbCons.COL_MEAN_BASELINE),...
                        'alpha',opt.significanceLevel);
                case 'ttest2'
                    [~,oxy_pValue] = ttest2(tmpDB(:,dbCons.COL_MEAN_TASK),...
                        tmpDB(:,dbCons.COL_MEAN_BASELINE),...
                        opt.significanceLevel,'both');
                otherwise
                    error('Unexpected test of significance.');
            end
            
            idx = find(db(:,dbCons.COL_SESSION) == sess ...
                & db(:,dbCons.COL_STIMULUS) == stim ...
                & db(:,dbCons.COL_CHANNEL) == ch ...
                & db(:,dbCons.COL_SIGNAL) == DEOXY);
            tmpDB = db(idx,:);
            deoxy_Sign = sign(mean(tmpDB(:,dbCons.COL_MEAN_TASK)...
                -tmpDB(:,dbCons.COL_MEAN_BASELINE)));
            switch (internalOpt_Test)
                case 'SingRank'
                    deoxy_pValue = signrank(tmpDB(:,dbCons.COL_MEAN_TASK),...
                        tmpDB(:,dbCons.COL_MEAN_BASELINE),...
                        'alpha',opt.significanceLevel);
                case 'ttest2'
                    [~,deoxy_pValue] = ttest2(tmpDB(:,dbCons.COL_MEAN_TASK),...
                        tmpDB(:,dbCons.COL_MEAN_BASELINE),...
                        opt.significanceLevel,'both');
                otherwise
                    error('Unexpected test of significance.');
            end
            
            chActivity_Sign(:,ch)=[oxy_Sign deoxy_Sign]';
            chActivity_pValue(:,ch)=[oxy_pValue deoxy_pValue]';
        %else %Not longer necessary as I'm initializaing to NaN
        %    chActivity_Sign(:,ch)=[NaN NaN]';
        %    chActivity_pValue(:,ch)=[NaN NaN]';
        end
    end
%     activity_sign(sess,stim) = {chActivity_Sign};
%     activity_pValue(sess,stim) = {chActivity_pValue};
%     M=[M; getPatterns(activity_sign{sess,stim},...
%                       activity_pValue{sess,stim})];
    M=[M; getPatterns(chActivity_Sign,...
                      chActivity_pValue)];

    if nStimulus == 1              
        sessLabels(end+1)={opt.sessionTags{sess}};
    elseif nSessions == 1
        sessLabels(end+1)={opt.stimulusTags{stim}};
    else
        sessLabels(end+1)={[opt.sessionTags{sess} '; ' ...
                            opt.stimulusTags{stim}]};
    end
    Im(end+1,:)=[1 sess 1 stim];
  end
end


%% Plot the matrix
hFig= figure;
%Colormaps:
opt.colormapOpt =2;
switch (opt.colormapOpt)
    case 1
        cmap=colormap(jet(16));
    case 2
        %%Option 2
        cmap = [ ...
            1.0000    1.0000    1.0000; ...
            1.0000    1.0000    0.6745; ...
            1.0000    0.5020    0.5020; ...
            1.0000    0.2000         0; ...
            0.6745    1.0000    1.0000; ...
            1.0000    1.0000    1.0000; ...
            1.0000    0.8078    0.6863; ...
            1.0000    0.5020    0.5020; ...
            0.5020    0.5020    1.0000; ...
            0.6863    0.8078    1.0000; ...
            1.0000    1.0000    1.0000; ...
            1.0000    1.0000    0.6745; ...
            0         0.2000    1.0000; ...
            0.5020    0.5020    1.0000; ...
            0.6745    1.0000    1.0000; ...
            1.0000    1.0000    1.0000];
    case 3
        %%Option 3
        cmap = [ ...
            1.0000    0.2000         0; ...
            1.0000    0.2000    0.3333; ...
            1.0000    0.2000    0.6667; ...
            1.0000    0.2000    1.0000; ...
            0.6600    0.2000         0; ...
            0.6600    0.2000    0.3333; ...
            0.6600    0.2000    0.6667; ...
            0.6600    0.2000    1.0000; ...
            0.3300    0.2000         0; ...
            0.3300    0.2000    0.3333; ...
            0.3300    0.2000    0.6667; ...
            0.3300    0.2000    1.0000; ...
            0    0.2000         0; ...
            0    0.2000    0.3333; ...
            0    0.2000    0.6667; ...
            0    0.2000    1.0000];
    otherwise
        cmap=colormap(jet(16));
end
%and add one colour for pattern 17 (missing data)
cmap=[cmap; 0 0 0];

colormap(cmap);

        
subplot(4,1,1:3);

image(M);
%Paint the grid manually
ylim=axis;
for ii=-1:(ylim(4)-ylim(3))
    line('XData',[ylim(1) ylim(2)],...
        'YData',[ii+0.5 ii+0.5],'Color','k','LineStyle','-',...
        'LineWidth',1.5);
end
nChannels=size(M,2);
for ii=1:nChannels
    line('XData',[ii+0.5 ii+0.5],...
        'YData',[ylim(3) ylim(4)],'Color','k','LineStyle','-',...
        'LineWidth',1.5);
end
box on


set(gca,'YTick',[1:nSessions*nStimulus]);
set(gca,'YTickLabel',sessLabels);
%set(gca,'YTickLabel',{'Control','Stimulus'})
xlabel('Channels');
title(['Pattern 4 is classical activation; ' ...
       ' Pattern 13 is classical deactivation']);

subplot(4,1,4);
tmp = reshape(1:16,4,4)';
image(tmp);
set(gca,'XTick',[1:4]);
set(gca,'YTick',[1:4]);
set(gca,'XTickLabel',{'++','+','-','--'})
set(gca,'YTickLabel',{'++','+','-','--'})
xlabel('\Delta HHb');
ylabel('\Delta HbO_2');
title(['Pattern color coding']);

if (opt.save)
    view(2);
    outputFilename=opt.outputFilename;
    saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
    print(['-f' num2str(gcf)],'-dtiff','-r300',...
        [opt.destinationFolder outputFilename '_300dpi.tif']);
    print(['-f' num2str(gcf)],'-djpeg','-r150',...
        [opt.destinationFolder outputFilename '_150dpi.jpg']);
    
    close gcf
    %And save the matrix itself
    save([opt.destinationFolder outputFilename '.mat'],...
        'M','sessLabels');
end



end




%% AUXILIAR FUNCTIONS
function p=getPatterns(Ms,Mp,alpha)
%Convert change directions and p values to patterns
%
% 16 activity patterns can be distinguish in total:
%
%   HbO2\HHb | ++| + | - | --|
%      ------+---+---+---+---+
%         ++ | 1 | 2 | 3 | 4 |
%      ------+---+---+---+---+
%          + | 5 | 6 | 7 | 8 |
%      ------+---+---+---+---+
%          - | 9 | 10| 11| 12|
%      ------+---+---+---+---+
%         -- | 13| 14| 15| 16|
%      ------+---+---+---+---+
%
%  ++ - Increment reached statistical significance
%   + - Increment did not reach statistical significance
%   - - Decrement did not reach statistical significance
%  -- - Decrement reached statistical significance
%
% Ms - Matrix of sign (direction of change)
% Mp - Matrix of p values (statistical significance)
% alpha - Optional. Statistical significance threshold (Default 0.05)

if ~exist('alpha','var')
    alpha=0.05;
end

tmpM=Ms.*Mp;
tmpM_HbO2=tmpM(1,:);
tmpM_HHb=tmpM(2,:);
p=zeros(1,length(tmpM)); %Patterns

%Check all 16 patterns:
idx=find((tmpM_HbO2 < alpha & tmpM_HbO2 >= 0) ...
        & (tmpM_HHb < alpha & tmpM_HHb >= 0));
p(idx)=1;

idx=find((tmpM_HbO2 < alpha & tmpM_HbO2 >= 0) ...
        & (tmpM_HHb >= alpha));
p(idx)=2;

idx=find((tmpM_HbO2 < alpha & tmpM_HbO2 >= 0) ...
        & (tmpM_HHb <= -alpha));
p(idx)=3;

idx=find((tmpM_HbO2 < alpha & tmpM_HbO2 >= 0) ...
        & (tmpM_HHb > -alpha & tmpM_HHb < 0));
p(idx)=4;


idx=find((tmpM_HbO2 >= alpha) ...
        & (tmpM_HHb < alpha & tmpM_HHb >= 0));
p(idx)=5;

idx=find((tmpM_HbO2 >= alpha) ...
        & (tmpM_HHb >= alpha));
p(idx)=6;

idx=find((tmpM_HbO2 >= alpha) ...
        & (tmpM_HHb <= -alpha));
p(idx)=7;

idx=find((tmpM_HbO2 >= alpha) ...
        & (tmpM_HHb > -alpha & tmpM_HHb < 0));
p(idx)=8;


idx=find((tmpM_HbO2 <= -alpha) ...
        & (tmpM_HHb < alpha & tmpM_HHb >= 0));
p(idx)=9;

idx=find((tmpM_HbO2 <= -alpha) ...
        & (tmpM_HHb >= alpha));
p(idx)=10;

idx=find((tmpM_HbO2 <= -alpha) ...
        & (tmpM_HHb <= -alpha));
p(idx)=11;

idx=find((tmpM_HbO2 <= -alpha) ...
        & (tmpM_HHb > -alpha & tmpM_HHb < 0));
p(idx)=12;


idx=find((tmpM_HbO2 > -alpha & tmpM_HbO2 < 0) ...
        & (tmpM_HHb < alpha & tmpM_HHb >= 0));
p(idx)=13;

idx=find((tmpM_HbO2 > -alpha & tmpM_HbO2 < 0) ...
        & (tmpM_HHb >= alpha));
p(idx)=14;

idx=find((tmpM_HbO2 > -alpha & tmpM_HbO2 < 0) ...
        & (tmpM_HHb <= -alpha));
p(idx)=15;

idx=find((tmpM_HbO2 > -alpha & tmpM_HbO2 < 0) ...
        & (tmpM_HHb > -alpha & tmpM_HHb < 0));
p(idx)=16;

%...and missing data
idx=find(any(isnan(tmpM_HbO2)) || any(isnan(tmpM_HHb)));
p(idx)=17;


end

