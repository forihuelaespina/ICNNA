function newAvg = incrementalAverage(r,Qk,k)
%Computes incremental average
%
% newAvg = incrementalAverage(r,Qk,k)
%
%% Computation of the Incremental average
%
%   Let Q_k denote the average of its first k rewards.
%Given this average and a (k+1)-st reward, r_{k+1},
%the average of all $k+1$ rewards can be computed by: 
%
%                 1
%Q_{k+1} = Q_k + --- (r_{k+1}-Q_k)
%                k+1
%
%% Parameters
%
% r - new (k+1)-st reward
% Qk - Current average of the first k rewards
% k - Current number of rewards
%
%% Output
%
% newAvg - The average of all k+1 rewards, Q_{k+1}
%
%
%
%
% Copyright 2010
% @date: 29-Nov-2010
% @author Felipe Orihuela-Espina
% @modified: 29-Nov-2010
%
% See also 
%

newAvg = Qk + (1/(k+1))*(r-Qk);
