function val = get(obj, propName)
% DATASOURCE/GET Get properties from the specified object
%and return the value
%
% val = get(obj, propName) Gets value of the property propName 
%
%
%% Properties
%
% 'ID' - The object identifier
% 'Name' - The name
% 'Device number' - A number identifying the device from which the data
%   originated
% 'Type' - The type of the data source. See dataSource for more
%   information on this attribute.
% 'Lock' - Whether existing the structrured data arise from the
%   defined raw data.
% 'RawData' - The raw Data if defined or an empty matrix if not defined.
% 'ActiveStructured' - The ID of the currently active structuredData
%
%
%
% Copyright 2008
% @date: 12-May-2008
% @author Felipe Orihuela-Espina
%
% See also dataSource, structuredData, set
%

switch propName
case 'ID'
   val = obj.id;
case 'Name'
   val = obj.name;
case 'DeviceNumber'
   val = obj.deviceNumber;
case 'Type'
    %Find the type on the fly
    val='';
    if ~(isempty(obj.structured))
        val=class(obj.structured{1});
    end
case 'Lock'
   val = obj.lock;
case 'RawData'
   val = obj.rawData;
case 'ActiveStructured'
   val = obj.activeStructured;
otherwise
   error([propName,' is not a valid property'])
end