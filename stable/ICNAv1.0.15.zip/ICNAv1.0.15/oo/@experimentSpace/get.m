function val = get(obj, propName)
% EXPERIMENTSPACE/GET Get properties from the specified object
%and return the value
%
% val = get(obj, propName) Gets value of the property propName 
%
%
%% Properties
%
%   'ID' - The experimentSpace identifier
%   'Name' - A name for the experimentSpace
%   'Description' -  A brief description of the experimentSpace
%   'RunStatus' - True if the experimentSpace has been computed
%       with the current configuration.
%   'Resampled' - True if resampling stage takes place. False otherwise
%   'Averaged' - True if averaging stage takes place. False otherwise
%   'Windowed' - DEPRECATED. True if window selection stage takes place.
%       False otherwise
%   'Normalized' - True if normaliztion stage takes place. False otherwise
%
%   'BaselineSamples' - Number of samples to be collected in
%       the baseline during the block splitting stage.
%   'RestSamples' - Maximum number of samples to be collected from
%       the rest during the block splitting stage.
%   'RS_Baseline' - Resampling stage number of samples for the baseline
%       in each block.
%   'RS_Task' - Resampling stage number of samples for the task
%       in each block.
%   'RS_Rest' - Resampling stage number of samples for the
%       rest in each block.
%   'WS_Onset' - Window selection stage number of samples from the
%       onset of the task in the block to start the window.
%   'WS_Duration' - Window selection stage duration of the window.
%   'WS_BreakDelay' - Window selection stage break delay of the window.
%   'NormalizationMethod' - Window normalization stage method.
%   'NormalizationMean' - Window normalization stage mean value
%       after normalization. Only valid if normalization method
%       is set to 'normal'.
%   'NormalizationVar' - Window normalization stage variance value
%       after normalization. Only valid if normalization method
%       is set to 'normal'.
%   'NormalizationMin' - Window normalization stage range minimum
%       value after normalization. Only valid if normalization method
%       is set to 'range'.
%   'NormalizationMax' - Window normalization stage range maximum
%       value after normalization. Only valid if normalization method
%       is set to 'range'.
%   'NormalizationScope' - Window normalization stage scope.
%   'NormalizationDimension' - Window normalization stage dimension.
%
% ==Derived attributes
%   'NumPoints' - Get the number of points in the Experiment Space
%
%
% Copyright 2008-9
% @date: 12-Jun-2008
% @author Felipe Orihuela-Espina
%
% See also experimentSpace, set
%

switch propName
    case 'ID'
        val = obj.id;
    case 'Name'
        val = obj.name;
    case 'Description'
        val = obj.description;
    case 'RunStatus'
        val = obj.runStatus;
    case 'Averaged'
        val = obj.performAveraging;
    case 'Resampled'
        val = obj.performResampling;
    case 'Windowed'
        val = obj.performFixWindow;
        warning('ICNA:experimentSpace:set',...
                  ['This has been DEPRECATED. ' ...
                  'Please refer to experimentSpace class ' ...
                  'documentation.']);
    case 'Normalized'
        val = obj.performNormalization;
    case 'BaselineSamples'
        val = obj.baselineSamples;
    case 'RestSamples'
        val = obj.restSamples;
    case 'RS_Baseline'
        val = obj.rsBaseline;
    case 'RS_Task'
        val = obj.rsTask;
    case 'RS_Rest'
        val = obj.rsRest;
    case 'WS_Onset'
        val = obj.fwOnset;
    case 'WS_Duration'
        val = obj.fwDuration;
    case 'WS_BreakDelay'
        val = obj.fwBreakDelay;
    case 'NormalizationMethod'
        val = obj.normalizationMethod;
    case 'NormalizationMean'
        val = obj.normalizationMean;
    case 'NormalizationVar'
        val = obj.normalizationVar;
    case 'NormalizationMin'
        val = obj.normalizationMin;
    case 'NormalizationMax'
        val = obj.normalizationMax;
    case 'NormalizationScope'
        val = obj.normalizationScope;
    case 'NormalizationDimension'
        val = obj.normalizationDimension;
% ==Derived attributes
    case 'NumPoints'
        val = size(obj.Findex,1);
    otherwise
        error('ICNA:experimentSpace:get',...
            [propName,' is not a valid property']);
end