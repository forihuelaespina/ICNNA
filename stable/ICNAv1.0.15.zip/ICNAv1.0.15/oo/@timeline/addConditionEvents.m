function obj=addConditionEvents(obj,tag,events)
%TIMELINE/ADDCONDITIONEVENTS Adds the events for the condition referred by tag
%
% obj=addConditionEvents(obj,tag,events) Adds the events for
%   the experimental condition referred by tag to the existing
%   events if any. If the condition
%   has not been defined, a warning is issued and nothing is done.
%
% Copyright 2008
% @date: 18-Apr-2008
% @author Felipe Orihuela-Espina
%
% See also getCondition, addCondition, setConditionTag, removeCondition,
% getConditionEvents, setConditionEvents, removeConditionEvents
%

idx=findCondition(obj,tag);
if (isempty(idx))
    warning('ICNA:timeline:addConditionEvents:UndefinedCondition',...
        ['Condition ' tag ...
         ' not defined. Ignoring event addition attempt']);
else
    if isempty(events)
        events=zeros(0,2);
    end

    obj.conditions{idx}.events=...
        sortrows([obj.conditions{idx}.events; events]);
end
assertInvariants(obj)