function obj = set(obj,varargin)
% RAWDATA_ETG4000/SET Set object properties and return the updated object
%
% obj = set(obj,varargin) Sets the indicated property propName and
%    return the updated object
%
%
%This method extends the superclass set method
%
%% Properties
%
%== Inherited
% 'Description' - Changes the description of the object
% 'Date' - Changes the date associated with the object.
%
% ==IOthers
% 'Version' - Version of data strcutre of the ETG-4000 file
% 'SubjectName' - The subject's name
% 'SubjectSex' - The subject's sex
% 'SubjectAge' - The subject's age in years
% 'PreTime' - Pre time
% 'PostTime' - Post time
% 'RecoveryTime' - Recovery time
% 'BaseTime' - Baseline time
% 'FittingDegree' - Degree of the polynolmial function for detrending
% 'HPF' - High Pass Filter
% 'LPF' - Low Pass Filter
% 'MovingAverage' - Number of samples of a moving average filter
% 'NominalWavelengthSet' - Set of wavelength at which the device operates
%       assuming no error
% 'ProbeMode' - A description of an optode array set
% 'nChannels' - Number of channels in the optode array
% 'SamplingRate' - Sampling Rate in [Hz]
% 'nBlocks' - Number of trials
% 'LightRawData' - The light intensitites recorded
% 'Marks' - Vector representing the timeline
% 'Timestamps' - Vector of sample acquisition timestamps in [s]
%       Relative to the object's Date. Note that no check
%       is done regarding the validity of the timestamps.
%
%
%
% Copyright 2008-10
% @date: 13-Jun-2008
% @author Felipe Orihuela-Espina
% @modified: 21-Jul-2010
%
% See also rawData.set, get
%

propertyArgIn = varargin;
while length(propertyArgIn) >= 2,
   prop = propertyArgIn{1};
   val = propertyArgIn{2};
   propertyArgIn = propertyArgIn(3:end);
   switch prop
    case 'Version'
        if (ischar(val))
            obj.version = val;
        else
            error('Value must be a string');
        end

%Patient information
    case 'SubjectName'
        if (ischar(val))
            obj.userName = val;
        else
            error('Value must be a string');
        end

    case 'SubjectSex'
        if (ischar(val))
            obj.userSex = val;
        else
            error('Value must be a string');
        end

    case 'SubjectAge'
        if (isscalar(val) && isreal(val))
            obj.userAge = val;
        else
            error('Value must be numeric');
        end

%Analysis information (for presentation only)
    case 'PreTime'
        if (isscalar(val) && (floor(val)==val) && val>0)
            obj.preTime = val;
        else
            error('Value must be a positive integer');
        end

    case 'PostTime'
        if (isscalar(val) && (floor(val)==val) && val>0)
            obj.postTime = val;
        else
            error('Value must be a positive integer');
        end

    case 'RecoveryTime'
        if (isscalar(val) && (floor(val)==val) && val>0)
            obj.recoveryTime = val;
        else
            error('Value must be a positive integer');
        end

    case 'BaseTime'
        if (isscalar(val) && (floor(val)==val) && val>0)
            obj.baseTime = val;
        else
            error('Value must be a positive integer');
        end

    case 'FittingDegree'
        if (isscalar(val) && (floor(val)==val) && val>0)
            obj.fittingDegree = val;
        else
            error('Value must be a positive integer');
        end

    case 'HPF'
        obj.hpf = val;
        
    case 'LPF'
        obj.hpf = val;
        
    case 'MovingAverage'
        if (isscalar(val) && (floor(val)==val) && val>0)
            obj.movingAvg = val;
        else
            error('Value must be a positive integer');
        end

%Measure information
    case 'NominalWavelenghtSet'
        if (isvector(val) && isreal(val))
            obj.wLengths = val;
        else
            error('Value must be a vector of wavelengths in nm.');
        end

    case 'ProbeMode'
        if (ischar(val))
            obj.probeMode = val;
        else
            error('Value must be a string');
        end

    case 'nChannels'
        if (isscalar(val) && (floor(val)==val) ...
                && val>0)
            obj.nChannels = val;
        else
            error('Value must be a positive integer');
        end


    case 'SamplingRate'
        if (isscalar(val) && isreal(val) && val>0)
            obj.samplingPeriod = val;
        else
            error('Value must be a positive real');
        end

    case 'nBlocks'
        if (isscalar(val) && (floor(val)==val) && val>0)
            obj.nBlocks = val;
        else
            error('Value must be a positive integer');
        end
%The data itself!!
    case 'LightRawData'
        if (isreal(val))
            obj.lightRawData = val;
        else
            error('A matrix of real numbers expected.');
        end
    case 'Marks'
        if (isvector(val) && all(floor(val)==val) && all(val>=0))
            obj.marks = val;
        else
            error('Value must be a vector positive integer.');
        end

    case 'Timestamps'
        if (isvector(val) && all(val>=0))
            obj.timestamps = val;
        else
            error('Value must be a vector positive integer.');
        end


   otherwise
        obj=set@rawData(obj, prop, val);
   end
end
