% @NEUROIMAGE
%
% Files
%   display    - NEUROIMAGE/DISPLAY Command window display
%   eq         - NEUROIMAGE/EQ Compares two objects.
%   neuroimage - Class neuroimage
%   get        - NEUROIMAGE/GET Get properties from the specified object
%   set        - NEUROIMAGE/SET Set object properties and return the updated object
