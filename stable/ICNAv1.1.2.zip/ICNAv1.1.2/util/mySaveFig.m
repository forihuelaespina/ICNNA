function mySaveFig(hfig,filename)
%Saves a figure in different formats at once
%
% mySaveFig(hfig,filename)
%
%
%
%MATLAB has recently changed the way gcf returns its output.
%It no longer gives you a handle number.
%Since I have to deal with old (in my laptop) and new (in the desktop)
%versions of matlab, I have to check this.
%
%
%% Parameters
%
% filename - Output filename without extension but including the directory
%
%
%
% @date: 29-Abr-2016
% @author: Felipe Orihuela-Espina
% @modified: 29-Abr-2016
%
%


saveas(gcf,[filename '.fig'],'fig');

if verLessThan('matlab','8.6')
    print(['-f' num2str(gcf)],'-dtiff','-r300',[filename '_300dpi.tif']);
    %print(['-f' num2str(gcf)],'-djpeg','-r150',[filename '_150dpi.jpg']);
    
else    
    print(gcf,'-dtiff','-r300',[filename '_300dpi.tif']);
    %print(gcf,'-djpeg','-r150',[filename '_150dpi.jpg']);

end

%close gcf
