function newStd = incrementalStd(r,Qk,stdk,k)
%Computes incremental standard deviation
%
% newStd = incrementalStd(r,Qk,stdk,k)
%
%% Computation of the Incremental standard deviation
%
%   Let Q_k denote the average (mean) of its first k rewards
%and stdk the standard deviation of these same first k rewards.
%Given this average and standard deviations and a (k+1)-st reward, r_{k+1},
%the standard deviation of all $k+1$ rewards can be computed by: 
%
%                / k-1         1                  \
%std_{k+1} = SQRT| --- stdk^2 + --- (r_{k+1}-Q_k)^2 |
%                \  k         k+1                 /
%
%
% See: Computation of the Incremental Variance (and from here the STD)
%   http://math.stackexchange.com/questions/102978/incremental-computation-of-standard-deviation
%
%% Parameters
%
% r - new (k+1)-st reward
% Qk - Current average of the first k rewards
% stdk - Current standard deviation of the first k rewards
% k - Current number of rewards
%
%% Output
%
% newStd - The standard deviation of all k+1 rewards, std_{k+1}
%
%
%
%
% Copyright 2010
% @date: 29-Nov-2010
% @author Felipe Orihuela-Espina
% @modified: 29-Nov-2010
%
% See also 
%

if (k==0)
    %Please note; that strictly, using the unbiased estimator (the one
    %that divides by N-1, the standard deviation of
    %a POPULATION of size 1 (that's when k=0) is undefined (due to 0/0)
    %but normally "accepted" to be 0 and
    %for a particular SAMPLE of size 1 (division by 0 only) is infinite
    %yet again normally "accepted" to be 0.
    %See: http://stackoverflow.com/questions/8023878/standard-deviation-of-one-element
    newStd = 0*r;%Just to ensure the right size
else
    newStd = sqrt(((k-1)/k)*stdk.^2 + (1/(k+1))*(r-Qk).^2);
end