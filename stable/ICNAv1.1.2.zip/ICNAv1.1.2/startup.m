%A setup script...
%
%
%Copyright 2007-2009
%Date: 1-Apr-2007
%Author: Felipe Orihuela-Espina
%

%There's the possibility of adding path directly or use the default
%startup.m file in the MATLAB root directory, but as this is a shared
%computer, I have preferred to do it this way.
s = pwd;
if ispc
    s(s=='\')='/';
end
mypath=[s '/'];
clear s


% %Set up path
% addpath([mypath]); %add this directory
% 
% files = dir(mypath);
% nFiles=length(files);
% for ii=1:nFiles
%     if files(ii).isdir
%         dirname=files(ii).name;
%         if dirname(1)~='@' %Ignore objects directories
%             addpath([mypath dirname]);
%         end
%     end
% end
%clear ii dirname nFiles
%clear files

%%Setup path
addpath(mypath);
%addpath([mypath 'broncoscope']);
%addpath([mypath 'broncoscope/sift']);
addpath([mypath 'diabetes']);
addpath([mypath 'drtoolbox']);
addpath([mypath 'drtoolbox/techniques']);
addpath([mypath 'external']);
addpath([mypath 'external/quaternions']);
addpath([mypath 'external/arrow3d']);
addpath([mypath 'external/HotellingT2']);
addpath([mypath 'external/kriging']);
addpath([mypath 'forceSensing']);
addpath([mypath 'GUI']);
%addpath([mypath 'help']);
addpath([mypath 'miscellaneous']);
addpath([mypath 'oo']);
addpath([mypath 'plotting']);
addpath([mypath 'util']);

addpath([mypath 'MaTrICES']); %Aurora Tool
addpath([mypath 'OAT']); %Optotrack Tool
addpath([mypath 'iTrack']); %Eye Tracking Tool
addpath([mypath 'HR']); %Heart Rate Monitoring

addpath([mypath 'mcml']); %Monte Carlo Modelling of Light Transport


%Initialize external packages
%WavePath; %WaveLab; installed in \MATLAB\R2011b\toolbox\Wavelab850
    %This package is used to compute the Index of Cognitive Activity in
    %iTrack
cd(mypath);


clear mypath
