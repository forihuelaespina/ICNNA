function batchBasicVisualization(E,options)
%Bacth for basic visualization
%
% batchBasicVisualization(E) generates all basic plots for a
%   NIRS experiment.
%
% batchBasicVisualization(E,options) generates all basic plots for a
%   NIRS experiment with the indicated options.
%
%
%% Parameter
%
% E - An (NIRS) experiment
%
% options - An struct of options
%   .fontSize - Font size to be used in the figure series
%   .destinationFolder - Destination folder. Default value is
%       'C:\Felipe\Research\NIRS\Images\<experimentName>\'
%   .save - True (default) if you want your figures to be saved. False
%       otherwise. Figures are saved in MATLAB .fig format and in
%       compressed .tif format at 300dpi.
%   .seriesSCHAVG - Generate serie of figures showing single channels
%       averaged across block. One figure per <subject, session, 
%       dataSource, channel, stimulus>. False by default.
%           Currently only work using 5 baseline
%           samples and 10 rest samples for the block splitting.
%           It only generates the figures for those clean channels
%   .seriesSCHNBA - Generate serie of figures showing single channels
%       non block averaged. One figure per <subject, session, 
%       dataSource, channel>. False by default.
%           It only generates the figures for those clean channels
%   .seriesACHNBA - Generate serie of figures showing all channels
%       non block averaged at once. One figure per <subject, session,
%       dataSource>. True by default.
%           It include all channels even if they are not clean
%           NOTE: Currently assumes 24 channels in two 3x3 optode
%               array disposition.
%   .seriesACHAVG - Generate serie of figures showing all channels
%       at once block averaged by stimulus. One figure per
%       <subject, session, dataSource, stimulus>. False by default.
%           It include all channels even if they are not clean
%           NOTE: Currently assumes 24 channels in two 3x3 optode
%               array disposition.
%
%
% Copyright 2009-10
% @date: 30-Apr-2009
% @author: Felipe Orihuela-Espina
% @modified: 18-Jan-2010
%
% See also plotChannel
%


expName=get(E,'Name');
%Remove spaces (to avoid problems with MATLAB)
expName(expName==' ')='_';


%% Deal with options
opt.save=true;
opt.destinationFolder=['C:\Felipe\Research\NIRS\Images\' ...
                        expName '\'];
opt.fontSize=13;
opt.seriesSCHAVG = false;
opt.seriesSCHNBA = false;
opt.seriesACHNBA = true;
opt.seriesACHAVG = false;
if exist('options','var')
    if isfield(options,'save')
        opt.save=options.save;
    end
    if isfield(options,'destinationFolder')
        opt.destinationFolder=options.destinationFolder;
    end
    if isfield(options,'fontSize')
        opt.fontSize=options.fontSize;
    end
    if isfield(options,'seriesSCHAVG')
        opt.seriesSCHAVG=options.seriesSCHAVG;
    end
    if isfield(options,'seriesSCHNBA')
        opt.seriesSCHNBA=options.seriesSCHNBA;
    end
    if isfield(options,'seriesACHNBA')
        opt.seriesACHNBA=options.seriesACHNBA;
    end
    if isfield(options,'seriesACHAVG')
        opt.seriesACHAVG=options.seriesACHAVG;
    end
end

subjectList=getSubjectList(E);
%subjectList=[1];
%subjectList=[26 27 28 29];
%subjectList=[14];
for subjID=subjectList
    s=getSubject(E,subjID);
    sessionList=getSessionList(s);
    for sessID=sessionList
        ss=getSession(s,sessID);
        dataSourceList=getDataSourceList(ss);
        for dataSourceID=dataSourceList
            ds=getDataSource(ss,dataSourceID);
            activeDataID=get(ds,'ActiveStructured');
            sd=getStructuredData(ds,activeDataID);
            t=get(sd,'Timeline');
            
            nChannels=get(sd,'NChannels');
            integrity=get(sd,'Integrity');
            for ch=1:nChannels
                if isClean(integrity,ch)
                    
                    %Series SCHAVG
                    if (opt.seriesSCHAVG)
                        opt.blockAveraging=true;
                        
                        nConds=getNConditions(t);
                        for stim=1:nConds
                            opt.blockCondTag=getConditionTag(t,stim);
                            [h]=plotChannel(sd,ch,opt);
                            title(['Subj=' num2str(subjID,'%04i') ...
                                '; Sess=' num2str(sessID,'%04i') ...
                                '; DS=' num2str(dataSourceID,'%04i') ...
                                '; Stim=' opt.blockCondTag ...
                                '; Ch=' num2str(ch)],...
                                'FontSize',opt.fontSize+2);
                            
                            if (opt.save)
                                outputFilename=[expName ...
                                    '_SCHAVG_'...
                                    'Subj' num2str(subjID,'%02i') ...
                                    'Sess' num2str(sessID,'%02i') ...
                                    'DS' num2str(dataSourceID,'%02i') ...
                                    'Stim' opt.blockCondTag ...
                                    'Ch' num2str(ch,'%02i')];
                                saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
                                print(['-f' num2str(gcf)],'-dtiff','-r300',...
                                    [opt.destinationFolder outputFilename '_300dpi.tif']);
                                close gcf
                            end
                        end
                    end %Series SCHAVG


                    %Series SCHNBA
                    if (opt.seriesSCHNBA)
                        [h]=plotChannel(sd,ch,opt);
                        title(['Subj= ' num2str(subjID,'%04i') ...
                            '; Sess= ' num2str(sessID,'%04i') ...
                            '; DS= ' num2str(dataSourceID,'%04i') ...
                            '; Ch=' num2str(ch)],...
                            'FontSize',opt.fontSize+2);
                        
                        if (opt.save)
                            outputFilename=[expName ...
                                '_SCHNBA_'...
                                'Subj' num2str(subjID,'%02i') ...
                                'Sess' num2str(sessID,'%02i') ...
                                'DS' num2str(dataSourceID,'%02i') ...
                                'Ch' num2str(ch,'%02i')];
                            saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
                            print(['-f' num2str(gcf)],'-dtiff','-r300',...
                                [opt.destinationFolder outputFilename '_300dpi.tif']);
                            close gcf
                        end
                    end %Series SCHNBA

                end
            end

            %Series ACHNBA
            if (opt.seriesACHNBA)
                [h]=plotAllChannels(sd); %Auxiliar function
                axes(h(2));
                title(['Subj= ' num2str(subjID,'%04i') ...
                    '; Sess= ' num2str(sessID,'%04i') ...
                    '; DS= ' num2str(dataSourceID,'%04i')]);
                
                if (opt.save)
                    outputFilename=[expName ...
                        '_ACHNBA'...
                        '_Subj' num2str(subjID,'%02i') ...
                        '_Sess' num2str(sessID,'%02i') ...
                        '_DS' num2str(dataSourceID,'%02i')];
                    saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
                    print(['-f' num2str(gcf)],'-dtiff','-r300',...
                        [opt.destinationFolder outputFilename '_300dpi.tif']);
                    close gcf
                end
            end %Series ACHNBA
            
            %Series ACHAVG
            if (opt.seriesACHAVG)
                nConds=getNConditions(t);
                for stim=1:nConds
                    condTag=getConditionTag(t,stim);
                    [h]=plotAllChannelsAvg(sd,condTag); %Auxiliar function
                    axes(h(2));
                    title(['Subj= ' num2str(subjID,'%04i') ...
                        '; Sess= ' num2str(sessID,'%04i') ...
                        '; DS= ' num2str(dataSourceID,'%04i')...
                        '; Stim= ' condTag]);
                    
                    if (opt.save)
                        outputFilename=[expName ...
                            '_ACHAVG'...
                            '_Subj' num2str(subjID,'%02i') ...
                            '_Sess' num2str(sessID,'%02i') ...
                            '_DS' num2str(dataSourceID,'%02i') ...
                            '_Stim' condTag];
                        saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
                        print(['-f' num2str(gcf)],'-dtiff','-r300',...
                            [opt.destinationFolder outputFilename '_300dpi.tif']);
                        close gcf
                    end
                end
            end %Series ACHAVG
            
        end %dataSource
        clear ss        
    end %sessions
    clear s
end %subjects

end


%% AUXILIAR FUNCTION
function [h]=plotAllChannels(sd)
%Plots all channels at the same time
%
%Currently assumes 24 channels and two 3x3 optode arrays
%
% sd - A NIRS_neuroimage data
%

opt.lineWidth=1.5;
opt.fontSize=8;
nChannels=24; %Note that I can get this from sd, but because
            %of the assumption, it is safer this way!
for ch=1:nChannels
    channelData=getChannel(sd,ch);
    nSamples=size(channelData,1);
    
    location=getLocation(ch);
    h(ch)=axes('Position',location);
%     line('XData',1:nSamples,...
%          'YData',channelData(:,1)+channelData(:,2),'Color','g',...
%             'LineStyle','--','LineWidth',opt.lineWidth);
%     line('XData',1:nSamples,...
%          'YData',channelData(:,1)-channelData(:,2),'Color','m',...
%             'LineStyle','--','LineWidth',opt.lineWidth);
    line('XData',1:nSamples,...
         'YData',channelData(:,1),'Color','r',...
            'LineStyle','-','LineWidth',opt.lineWidth);
    line('XData',1:nSamples,...
         'YData',channelData(:,2),'Color','b',...
            'LineStyle','-','LineWidth',opt.lineWidth);
    
    
    set(gca,'XTick',[]);
    box on, grid on
    %%Plot the Timeline
    %%Shade the regions of stimulus
    %%%IMPORTANT NOTE: If I try to first paint stimulus regions and
    %%%later the signal, at the moment will not work...
    shadeTimeline(gca,get(sd,'Timeline'));
    set(gca,'XLim',[1 nSamples]);
    
    
    ylim=axis;
    hText=text(0.85*ylim(2),0.85*ylim(4),num2str(ch));
    set(hText,'FontSize',opt.fontSize,...
            'FontWeight','bold',...
            'BackgroundColor','y');
end
end


function [h]=plotAllChannelsAvg(sd,condTag)
%Plots all channels at the same time (block averaged).
%
%Currently assumes 24 channels and two 3x3 optode arrays
%
% sd - A NIRS_neuroimage data
%
% condTag - A stimulus to average across
%

opt.lineWidth=1.5;
opt.fontSize=8;
nChannels=24; %Note that I can get this from sd, but because
            %of the assumption, it is safer this way!

%integrity=get(sd,'Integrity');
for ch=1:nChannels
%    if isClean(integrity,ch)
        location=getLocation(ch);
        h(ch)=axes('Position',location);
        opt.axesHandle=h(ch);
        opt.blockAveraging=true;
        opt.blockCondTag=condTag;
        opt.blockBaseline=10;
        opt.blockMaxRest=20;
        opt.blockResampling=true;
        opt.blockResamplingBaseline=15;
        opt.blockResamplingTask=30;
        opt.blockResamplingRest=30;
        opt.displayLegend = false;
        plotChannel(sd,ch,opt);
        nSamples=sum([opt.blockResamplingBaseline ...
                        opt.blockResamplingTask ...
                        opt.blockResamplingRest]);
    
        set(gca,'XTick',[]);
%        set(gca,'XLim',[1 nSamples]);
        xlabel([]);
        ylabel([]);
        title([]);
        
        
        ylim=axis;
        hText=text(0.85*ylim(2),0.85*ylim(4),num2str(ch));
        set(hText,'FontSize',opt.fontSize,...
            'FontWeight','bold',...
            'BackgroundColor','y');
%    end
end
end




function pos=getLocation(ch,mode)
%Return an position vector to place the channel axes
%
% ch - Channel number
% mode - Optode array mode, i.e. '3x3' (default)

switch (mode)
    case '3x3'
        nChannels = 24;
                %Each row is a channel.
        tmpChannelPositions = ...
            [0.09 0.78 0.136 0.17; ...
        	0.296 0.78 0.136 0.17; ...
        	0.03 0.59 0.136 0.17; ...
        	0.186 0.59 0.136 0.17; ...
        	0.342 0.59 0.136 0.17; ...
        	0.09 0.4 0.136 0.17; ...
        	0.296 0.4 0.136 0.17; ...
        	0.03 0.21 0.136 0.17; ...
        	0.186 0.21 0.136 0.17; ...
        	0.342 0.21 0.136 0.17; ...
        	0.09 0.02 0.136 0.17; ...
        	0.296 0.02 0.136 0.17; ...
        	0.572 0.78 0.136 0.17; ...
        	0.778 0.78 0.136 0.17; ...
        	0.518 0.59 0.136 0.17; ...
        	0.674 0.59 0.136 0.17; ...
        	0.83 0.59 0.136 0.17; ...
        	0.572 0.4 0.136 0.17; ...
        	0.778 0.4 0.136 0.17; ...
        	0.518 0.21 0.136 0.17; ...
        	0.674 0.21 0.136 0.17; ...
        	0.83 0.21 0.136 0.17; ...
        	0.572 0.02 0.136 0.17; ...
        	0.778 0.02 0.136 0.17];
    otherwise
        error('Mode not yet ready or not recognised.');
end

pos=[0.1 0.1 0.9 0.9];
if ch>=1 && ch<=nChannels
    pos=tmpChannelPositions(ch,:);
end

end