function element=runIntegrity(element,options)
%Recursively check the integrity for element and all its children
%
% E=runIntegrity(E)
%
% Subj=runIntegrity(Subj)
%
% Sess=runIntegrity(Sess)
%
% DSrc=runIntegrity(DSrc)
%
% SData=runIntegrity(SData)
%
% [...]=runIntegrity(...,options)
%
%
%
%% Parameters
%
% E - An experiment object
%
% Subj - A subject object
%
% Sess - A session object
%
% DSrc - A dataSource object
%
% options - A struct array with the selected tests and a verbose option
%
%% Output
%
% The same input element but with the integrity test run.
%   
%
%
% Copyright 2008-9
% @date: 8-Jul-2008
% @author Felipe Orihuela-Espina
% @modified: 2-Dec-2009
%
% See also structuredData.checkIntegrity, getIntegrityReport,
%   addVisualIntegrity
%

optVerbose=true;
if isfield(options,'verbose')
    optVerbose=options.verbose;
end


if (isa(element,'structuredData'))
	%Find the tests
	classType=class(element);
	tests=options.(classType);
	testNames=fieldnames(tests);
	tmpTests=cell(1,2*length(testNames));
	for ll=1:length(testNames) 
		tmpTests(2*ll-1)={testNames{ll}};
		tmpTests(2*ll)={true};
    end
    if (optVerbose)
        tmpTests(end+1)={'verbose'};
        tmpTests(end+1)={true};
    end
    %call the check integrity
    element=checkIntegrity(element,tmpTests);
    if (optVerbose)
        disp([datestr(now,13) ': runIntegrity - Done. ']);
    end
	
elseif (isa(element,'dataSource'))
	%Get the active data if any
	activeIdx=get(element,'ActiveStructured');
	if (activeIdx~=0)
        if (optVerbose)
            disp([datestr(now,13) ': runIntegrity - Active Data ']);
        end

        child=getStructuredData(element,activeIdx);
		child=runIntegrity(child,options);
		element=setStructuredData(element,activeIdx,child);
	end

elseif (isa(element,'session'))
	%Visit all dataSource
	childIDList=getDataSourceList(element);
    nChildren=length(childIDList);
	for childID=childIDList
        if (optVerbose)
            pos=find(childID==childIDList);
            disp([datestr(now,13) ': runIntegrity - Data Source ' ...
                    num2str(pos) '/' num2str(nChildren)]);
        end

		child=getDataSource(element,childID);
		child=runIntegrity(child,options);
		element=setDataSource(element,childID,child);
	end

elseif (isa(element,'subject'))
	%Visit all Sessions
	childIDList=getSessionList(element);
    nChildren=length(childIDList);
	for childID=childIDList
        if (optVerbose)
            pos=find(childID==childIDList);
            disp([datestr(now,13) ': runIntegrity - Session ' ...
                    num2str(pos) '/' num2str(nChildren)]);
        end

		child=getSession(element,childID);
		child=runIntegrity(child,options);
		element=setSession(element,childID,child);
	end

elseif (isa(element,'experiment'))
	%Visit all Subjects
	childIDList=getSubjectList(element);
    nChildren=length(childIDList);
	for childID=childIDList
        if (optVerbose)
            pos=find(childID==childIDList);
            disp([datestr(now,13) ': runIntegrity - Subject ' ...
                    num2str(pos) '/' num2str(nChildren)]);
        end

		child=getSubject(element,childID);
		child=runIntegrity(child,options);
		element=setSubject(element,childID,child);
	end
end