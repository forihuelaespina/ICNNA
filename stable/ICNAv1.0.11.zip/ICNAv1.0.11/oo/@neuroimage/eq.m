function res=eq(obj,obj2)
%NEUROIMAGE/EQ Compares two objects.
%
% obj1==obj2 Compares two objects.
%
% res=eq(obj1,obj2) Compares two objects.
%
%
% Copyright 2008
% @date: 11-Jul-2008
% @author Felipe Orihuela-Espina
%
% See also neuroimage
%

if ~isa(obj2,'neuroimage')
    res=false;
    return
end

res=eq@structuredData(obj,obj2);
if ~res
    return
end

%Nothing else to do 