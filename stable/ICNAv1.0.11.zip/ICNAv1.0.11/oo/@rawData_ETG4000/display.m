function display(obj)
%RAWDATA_ETG4000/DISPLAY Command window display of a rawData_ETG4000
%
%Produce a string representation of the object, which is
%then displayed on the with an output similar to the standard
%MATLAB output.
%
% Copyright 2008
% @date: 13-May-2008
% @author Felipe Orihuela-Espina
%
% See also rawData_ETG4000, get, set
%

disp(' ');
disp([inputname(1),'= ']);
disp(' ');
%Inherited
disp(['   ID: ' num2str(get(obj,'ID'))]);
disp(['   Description: ' get(obj,'Description')]);
disp(['   date: ' get(obj,'Date')]);

disp(['   File Version: ' obj.version]);
%Patient Information
disp(['   User Name: ' obj.userName]);
disp(['   User Age: ' num2str(obj.userAge)]);
disp(['   User Sex: ' obj.userSex]);

%Analysis Information
disp(['   Pre Time[s]: ' num2str(obj.preTime)]);
disp(['   Post Time[s]: ' num2str(obj.postTime)]);
disp(['   Recovery Time[s]: ' num2str(obj.recoveryTime)]);
disp(['   Base Time[s]: ' num2str(obj.baseTime)]);
disp(['   Fitting degree: ' num2str(obj.fittingDegree)]);
disp(['   HPF[Hz]: ' obj.hpf]);
disp(['   LPF[Hz]: ' obj.lpf]);
disp(['   Moving Average[s]: ' num2str(obj.movingAvg)]);

%Measurement Information
disp(['   Wavelengths[nm]: ' num2str(obj.wLengths)]);
disp(['   Probe Mode: ' obj.probeMode]);
disp(['   Number of Channels: ' num2str(obj.nChannels)]);
disp(['   Sampling Period[s]: ' num2str(obj.samplingPeriod)]);
disp(['   Repeat Count: ' num2str(obj.nBlocks)]);

%Data
disp(['   Data Size: ' num2str(size(obj.lightRawData))]);

disp(' ');
