function assertInvariants(obj)
%TIMELINE/ASSERTINVARIANTS Ensures the invariants of timeline is met
%
% assertInvariants(obj) Asserts the invariants
%
%% Invariants
%
%   Invariant: Timeline length is always 0 or positive
%       obj.length>=0;
%
%   Invariant: For all conditions c
%       c.tag~=''
%
%   Invariant: For all pair of conditions ci and cj
%       ci.tag~=cj.tag
%
%   Invariant: For all conditions c and all events i
%       c.onset(i)+c.duration(i)-1 < c.onset(i+1)
%
%          Note that the above imply that events are sorted
%           according to their onsets!!
%
%   Invariant: For all conditions c and all events i
%       c.onset(i) > 0
%
%   Invariant: For all conditions c and all events i
%       c.duration(i) >= 0
%
%   Invariant: For all conditions c and all events i
%       c.onset(i)+c.duration(i)-1 <= timeline.length
%
%
%   Invariant: Exclusory state matrix is squared, symmetric and
%	has the same number of rows (and columns) as there
%	are conditions.
%
%   Invariant: A condition cannot be exclusory with itself
%	The main diagonal of exclusory state matrix is always 0.
%
%   Invariant: For exclusory cond_i and cond_j |i~=j then
%	their events do not overlap
%
%       
% Copyright 2008
% date: 18-Apr-2008
% Author: Felipe Orihuela-Espina
%
% See also timeline
%

assert(obj.length>=0,'Timeline length must be 0 or positive.');


nConditions=length(obj.conditions);
for ii=1:nConditions
    tag=obj.conditions{ii}.tag;
    assert(~strcmp(tag,''), 'Condition %d: Empty Tag',ii);
    tagIdx=findCondition(obj,tag);
    assert(ii==tagIdx, ['Condition %s: Tag' ...
                    ' already defined'],tag);
    events=obj.conditions{ii}.events;
    [nEvents,temp]=size(events);
    assert(temp==2, ['Condition %s: Events structure is' ...
                    ' corrupted'],tag);
    onsets = events(:,1);
    assert(all(onsets>0),['Condition %s: Onsets must be ' ...
                    ' bigger than 0'],tag);
%     assert(all(floor(onsets)==onsets),['Condition %s: Onsets must be ' ...
%                     ' positive integers'],tag);
    assert(issorted(onsets),['Condition %s: Onsets are' ...
                    ' not sorted'],tag);
    durations = events(:,2);
    assert(all(floor(durations)==durations),...
                    ['Condition %s: Durations must be ' ...
                    ' positive integers'],tag);
    assert(all(durations>=0),['Condition %s: Durations cannot' ...
                    ' be negative'],tag);
    for jj=1:nEvents-1
        assert(onsets(jj)+durations(jj)-1<onsets(jj+1),...
                ['Condition %s: Invariant ' ...
                 '(onsets(jj)+durations(jj)<onsets(jj+1))' ...
                ' does not hold.'],tag);
        assert(onsets(jj)+durations(jj)-1<=obj.length,...
                ['Condition %s: Invariant ' ...
                 '(onsets(jj)+durations(jj)<=obj.length)' ...
                 ' does not hold.'],tag)
    end
    if (nEvents>0)
        assert(onsets(end)+durations(end)-1<=obj.length,...
                ['Condition %s: Invariant ' ...
                 '(onsets(jj)+durations(jj)<=obj.length)' ...
                 ' does not hold.'],tag)
    end


end

%Exclusory behaviour
 %Check square
 [nRows,nCols]=size(obj.exclusory);
 assert(nRows==nCols, 'Exclusory state matrix is not square');
 %Check symmetry
 assert(all(all(obj.exclusory==obj.exclusory')),...
	'Exclusory state matrix is not symmetric');
 %Has the same number of rows as there are conditions
 assert(nRows==length(obj.conditions),...
	['Exclusory state matrix size does not ' ...
	 'correspond with number of conditions.']);
 %A condition is not exclusory with itself
 B=1-eye(length(obj.conditions));
 assert(all(diag(obj.exclusory)==diag(B)),...
	'Conditions cannot be exclusory with themselves');
 %Now check that there's no overlap     
 for row=2:nRows
    for col=1:row-1
        if (obj.exclusory(row,col))
            events=[obj.conditions{row}.events; ...
                obj.conditions{col}.events];
            events=sortrows(events);
            onsets = events(:,1);
            durations = events(:,2);
            nEvents=size(events,1);
            for jj=1:nEvents-1
                assert(onsets(jj)+durations(jj)-1<onsets(jj+1),...
                    'Events overlap in exclusory conditions.');
            end
        end
    end
end
