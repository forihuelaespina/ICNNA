function val = get(obj, propName)
% TIMELINE/GET Get properties from the specified object
%and return the value
%
% val = get(obj, propName) Gets value of the property propName 
%
%% Properties
%
% 'Length' - The length of the timeline in samples.
%
%
%
% Copyright 2008
% @date: 18-Apr-2008
% @author Felipe Orihuela-Espina
%
% See also timeline, set, getCondition, getConditionTag,
%   getConditionEvents
%

switch propName
case 'Length'
   val = obj.length;
otherwise
   error([propName,' is not a valid property'])
end