function n=getNConditions(obj)
%TIMELINE/GETNCONDITIONS Get the number of defined conditions in the
%timeline
%
% n=getNConditions(obj) Get the number of defined conditions in the
%   timeline
%
%
% Copyright 2008
% @date: 18-Apr-2008
% @author Felipe Orihuela-Espina
%
%See also get, getCondition, getConditionTag, getConditionEvents
%

n=length(obj.conditions);

