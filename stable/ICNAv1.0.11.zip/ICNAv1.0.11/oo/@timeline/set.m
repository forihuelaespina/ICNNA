function obj = set(obj,varargin)
% TIMELINE/SET Set object properties and return the updated object
%
% obj = set(obj,'PropertyName',propertyValue) Set object properties and
%   return the updated object
%
%% Properties
%
% 'Length' - Length of the timeline in number of samples
%When updating the 'Length', if the current timeline has
%events defined that last beyond the new size, this operation
%will issue a warning before cropping or removing those events.
%
% Copyright 2008
% @date: 18-Apr-2008
% @author Felipe Orihuela-Espina
%
%See also get, addCondition, addConditionEvents, setConditionEvents
%
propertyArgIn = varargin;
while length(propertyArgIn) >= 2,
   prop = propertyArgIn{1};
   val = propertyArgIn{2};
   propertyArgIn = propertyArgIn(3:end);
   switch prop
    case 'Length'
        if (isscalar(val) && (val==floor(val)))
            %Remove or crop events beyond the new length.
            res=cropOrRemoveEvents(val);
            if (res)
                warning('ICNA:timeline:set:Length:EventsCropped',...
                    ['Events lasting beyond the new length ' ...
                     'will be cropped or removed']);
            end
            obj.length = val;
        else
            error('Value must be a scalar natural/integer');
        end

    otherwise
      error(['Property ' prop ' not valid.'])
   end
end
assertInvariants(obj);

%% Auxiliar Nested functions
function res=cropOrRemoveEvents(newLength)
    res=false;
    nCond=getNConditions(obj);
    for cc=1:nCond
        ctag=getConditionTag(obj,cc);
        e=getConditionEvents(obj,ctag);
        if (~isempty(e))
            onsets=e(:,1);
            %Remove those events which start after the new length
            idx=find(onsets>newLength);
            if (~isempty(idx))
                res=true;
            end
            e(idx,:)=[];
            %Crop those events which start before the new lengh
            %but last beyond that length
            onsets=e(:,1);
            durations=e(:,2);
            endings=onsets+durations;
            idx=find(endings>newLength);
            if (~isempty(idx))
                res=true;
            end
            e(idx,2)=newLength-onsets(idx);
        end
        obj=setConditionEvents(obj,ctag,e);
    end
end
end