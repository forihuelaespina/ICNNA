% @CLUSTER
%
% Files
%   cluster - A cluster (or class) simply holds a record of points which
%   display - CLUSTER/DISPLAY Command window display of a cluster
%   eq      - CLUSTER/EQ Compares two objects.
%   get     - CLUSTER/GET Get properties from the specified object
%   set     - CLUSTER/SET Set object properties and return the updated object
