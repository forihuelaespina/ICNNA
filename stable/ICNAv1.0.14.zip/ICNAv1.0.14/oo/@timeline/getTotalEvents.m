function n=getTotalEvents(obj)
%TIMELINE/GETTOTALEVENTS Get the total number of events across all conditions
%
% max = getTotalEvents(obj) Get the total number of events defined
%   in the timeline across all defined conditions.
%   If no conditions have been defined
%   then this function returns an empty matrix. Note that
%   although conditions may exist there is still the
%   possibility that no events have been declared for any conditions
%   and hence a value 0 will be returned.
%
% Copyright 2008
% @date: 18-Jun-2008
% @author Felipe Orihuela-Espina
%
% See also setConditionEvents, addConditionEvents, removeConditionEvents,
%   getNEvents, getMaxEvents
%
n=[];
if ~isempty(obj.conditions)
    n=0;
    for ii=1:length(obj.conditions)
        n=n+size(obj.conditions{ii}.events,1);
    end
end