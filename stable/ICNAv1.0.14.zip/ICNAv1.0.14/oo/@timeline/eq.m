function res=eq(obj,obj2)
%TIMELINE/EQ Compares two objects.
%
% obj1==obj2 Compares two objects.
%
% res=eq(obj1,obj2) Compares two objects.
%
%
% Copyright 2008
% @date: 11-Jul-2008
% @author Felipe Orihuela-Espina
%
% See also timeline
%

res=true;
if ~isa(obj2,'timeline')
    res=false;
    return
end

res = res && (get(obj,'Length')==get(obj2,'Length'));

e1=getExclusory(obj);
e2=getExclusory(obj2);
res = res && all(all(e1==e2));

res = res && (getNConditions(obj)==getNConditions(obj2));
if ~res
    return
end

nCond=getNConditions(obj);
for cc=1:nCond
    c1Tag=getConditionTag(obj,cc);
    c2Tag=getConditionTag(obj2,cc);
    
    res = res && strcmp(c1Tag,c2Tag);
    res = res && all(all(getConditionEvents(obj,c1Tag),...
                         getConditionEvents(obj2,c2Tag)));   
    if ~res
        return
    end
end
