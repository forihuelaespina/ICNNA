% @EXPERIMENTSPACE
%
% Files
%   assertInvariants - EXPERIMENTSPACE/ASSERTINVARIANTS Ensures the invariants are met
%   compute          - EXPERIMENTSPACE/COMPUTE Compute the space with current configuration
%   display          - EXPERIMENTSPACE/DISPLAY Command window display
%   experimentSpace  - An experimentSpace converts the experiment data into a suitable
%   get              - EXPERIMENTSPACE/GET Get properties from the specified object
%   getSubset        - EXPERIMENTSPACE/GETSUBSET Access to a subset of points in the space
%   set              - EXPERIMENTSPACE/SET Set object properties and return the updated object
