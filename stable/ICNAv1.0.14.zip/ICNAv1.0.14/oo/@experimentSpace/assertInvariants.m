function assertInvariants(obj)
%EXPERIMENTSPACE/ASSERTINVARIANTS Ensures the invariants are met
%
% assertInvariants(obj) Asserts the invariants
%
%% Invariants
%
%   Invariant: Number of points in Fvectors and Findex
%       must be coincident.
%
%
% Copyright 2008
% date: 20-Apr-2008
% Author: Felipe Orihuela-Espina
%
% See also experimentSpace
%

    
%Number of points in Fvectors (cols) and the number of
%points i Findex (rows) must be coincident.
assert(length(obj.Fvectors)==size(obj.Findex,1),...
        'experimentSpace.assertInvariants: Corrupted number of points.');    
