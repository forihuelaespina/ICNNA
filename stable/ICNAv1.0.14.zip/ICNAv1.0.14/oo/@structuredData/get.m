function val = get(obj, propName)
%STRUCTUREDDATA/GET Get properties from the specified object
%and return the value
%
% val = get(obj, propName) Gets value of the property propName 
%
%% Properties
%
% 'ID' - The neuroimage ID.
% 'Description' - A short description of the image
% 'NSamples' - Number of samples 
% 'NChannels' - Number of channels
% 'NSignals' - Number of signals
% 'Timeline' - The image timeline
% 'Integrity' - The image integrity status per picture element
% 'Data' - The image data itself
% 'SignalTags' - The list of signal tags
%
% Copyright 2008
% @date: 27-Apr-2008
% @author Felipe Orihuela-Espina
%
% See also structuredData, getBlock, getSample, getChannel, getSignal
%

switch propName
case 'ID'
   val = obj.id;
case 'Description'
   val = obj.description;
case 'NSamples'
   val = size(obj.data,1);
case 'NChannels'
   val = size(obj.data,2);
case 'NSignals'
   val = size(obj.data,3);
case 'Timeline'
   val = obj.timeline;
case 'Data'
   val = obj.data;
case 'Integrity'
   val = obj.integrity;
case 'SignalTags'
   val = obj.signalTags;
otherwise
   error([propName,' is not a valid property'])
end