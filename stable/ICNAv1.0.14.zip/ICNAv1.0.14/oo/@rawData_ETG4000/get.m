function val = get(obj, propName)
% RAWDATA_ETG4000/GET Get properties from the specified object
%and return the value
%
% val = get(obj, propName) Gets value of the property propName 
%
%This method extends the superclass get method
%
%% Properties
%
%== Inherited
% 'Description' - Gets the object's description
% 'Date' - Gets the date associated with the object.
%       See also timestamps
%
% ==IOthers
% 'Version' - Version of data strcutre of the ETG-4000 file
% 'SubjectName' - The subject's name
% 'SubjectSex' - The subject's sex
% 'SubjectAge' - The subject's age in years
% 'PreTime' - Pre time
% 'PostTime' - Post time
% 'RecoveryTime' - Recovery time
% 'BaseTime' - Baseline time
% 'FittingDegree' - Degree of the polynolmial function for detrending
% 'HPF' - High Pass Filter
% 'LPF' - Low Pass Filter
% 'MovingAverage' - Number of samples of a moving average filter
% 'NominalWavelengthSet' - Set of wavelength at which the device operates
%       assuming no error
% 'ProbeMode' - A description of an optode array set
% 'nChannels' - Number of channels in the optode array
% 'SamplingRate' - Sampling Rate in [Hz]
% 'nBlocks' - Number of trials
% 'LightRawData' - The light intensitites recorded
% 'Marks' - Vector representing the timeline
% 'Timestamps' - Vector sample acquisition timestamps relative
%       to object's date (inherited)
%
%
%
% Copyright 2008-10
% @date: 13-Jun-2008
% @author Felipe Orihuela-Espina
% @date: 21-Jul-2010
%
% See also rawData.get, set
%

switch propName
case 'Version'
   val = obj.version;
%Patient information
case 'SubjectName'
   val = obj.userName;
case 'SubjectSex'
   val = obj.userSex;
case 'SubjectAge'
   val = obj.userAge;
%Analysis information (for presentation only)
case 'PreTime'
   val = obj.preTime;
case 'PostTime'
   val = obj.postTime;
case 'RecoveryTime'
   val = obj.recoveryTime;
case 'BaseTime'
   val = obj.baseTime;
case 'FittingDegree'
   val = obj.fittingDegree;
case 'HPF'
   val = obj.hpf;
case 'LPF'
   val = obj.hpf;
case 'MovingAverage'
   val = obj.movingAvg;
%Measure information
case 'NominalWavelenghtSet'
   val = obj.wLengths;
case 'ProbeMode'
   val = obj.probeMode;
case 'nChannels'
   val = obj.nChannels;
case 'SamplingRate'
   val = obj.samplingPeriod;
case 'nBlocks'
   val = obj.nBlocks;
%The data itself!!
case 'LightRawData'
   val = obj.lightRawData;%The raw light intensity data.
case 'Marks'
   val = obj.marks;%The stimulus marks.
case 'Timestamps'
   val = obj.timestamps;
   
otherwise
   val = get@rawData(obj, propName);
end