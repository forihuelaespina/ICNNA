%Class rawData_ETG4000
%
%A rawData_ETG4000 represents the experimentally recorded data
%with a HITACHI ETG 4000 NIRS device during a fNIRS session.
%This data is not yet converted to a proper neuroimage.
%
%This class also contains some experimental parameters such as
%the sampling rate etc...
%
% The interoptode distance is fixed at 3cm.
% The Hitachi ETG-4000 OTS operates at two wavelengths:
%   695 +/- 20nm
%   830 +/- 20nm
%with and optical intensity of 2.0mW per wavelength (see ETG-4000
%Instruction manual, Section 12 pg. 12-1) and has 24 channels or
%picture elements by default. The deviation from the
%nominal wavelength is recorded in the raw light intensity files.
%
%The main attribute is lightRawData holding the raw light intensity
%data. It is a matrix sized
% (nWLengths*nChannels+1) x nSamples.
%   Note that each channel has nWLengths measurements at the different
%   wavelengths.
%
%               Sample_1  Sample_2 ... Sample_n
%   Ch1^l1
%   ...
%   Ch1^lm
%   Ch2^l1
%   ...
%   ChC^lm
%
%
%
%% Remarks
%
% Private function
%
%       coe=table_abscoeff;
%
% is actually copyrighted by fOSA and licenced under the GNU end user
% licence agreement.
%
%
%% Superclass
%
% rawData - An abstract class for holding raw data.
%
%
%% Properties
%
%   .version - The data file version
%  == Patient information
%   .userName - The user name
%   .userAge - The user age
%   .userSex - The user sex
%  == Analysis information(for presentation only)
%   .preTime=1; %in [s]
%   .postTime=1; %in [s]
%   .recoveryTime=1; %in [s]
%   .baseTime=1; %in [s]
%   .fittingDegree=1;
%   .hpf ='No Filter'; %High pass cutoff frequency in [Hz] or 'No Filter'
%   .lpf ='No Filter'; %Low pass cutoff frequency in [Hz] or 'No Filter'
%   .movingAvg=1; %Moving average smoothing for presentation only
%  == Measurement information
%   .wLengths=[695 830] - The nominal wavelengths at which the light
%             intensities were acquired in [nm].
%   .probeMode - A string containing the probe mode.
%   .nChannels - The number of Channels derived from the probeMode.
%   .samplingPeriod - Sampling rate i.e. time between two
%             measurements in [s]
%   .nBlocks - Repeat Count
%  == The data
%   .lightRawData - The raw light intensity data.
%   .marks - Stimulus marks
%   .timestamps - Timestamps relative to the object 'Date' (inherited)
%       in [s]. Absolute timestamps are obtained from the
%       Time column in the data section.
%       	+ Note that the first time stamp does NOT have to be 0!.
%           + Milliseconds are expressed as a fraction of seconds.
%  
%% Methods
%
% Type methods('rawData_ETG4000') for a list of methods
%
%
% Copyright 2008-10
% @date: 12-May-2008
% @author: Felipe Orihuela-Espina
% @modified: 21-Jul-2010
%
% See also rawData, rawData_ETG4000
%
classdef rawData_ETG4000 < rawData
    properties (SetAccess=private, GetAccess=private)
        version='1.06';
        %Patient information
        userName='';
        userSex='';
        userAge=[];
        %Analysis information (for presentation only)
        preTime=1; %in [s]
        postTime=1; %in [s]
        recoveryTime=1; %in [s]
        baseTime=1; %in [s]
        fittingDegree=1;
        hpf ='No Filter'; %High pass cutoff frequency in [Hz] or 'No Filter'
        lpf ='No Filter'; %Low pass cutoff frequency in [Hz] or 'No Filter'
        movingAvg=1; %Moving average smoothing for presentation only
        %Measure information
        wLengths=[695 830];%The nominal wavelengths at which the light
            %intensities were acquired in [nm].
        probeMode='3x3';%A string containing the probe mode.
        nChannels=24;%The number of Channels derived from the probeMode.
        samplingPeriod=0.1%Sampling rate i.e. time between two
                        %measurements in [s]
        nBlocks=5; %Repeat Count
        %The data itself!!
        lightRawData=[];%The raw light intensity data.
        marks=[];%The stimulus marks.
        timestamps=[];%Timestamps.
    end
 
    methods    
        function obj=rawData_ETG4000(varargin)
            %RAWDATA_ETG4000 RawData_ETG4000 class constructor
            %
            % obj=rawData_ETG4000() creates a default rawData_ETG4000
            %   with ID equals 1.
            %
            % obj=rawData_ETG4000(obj2) acts as a copy constructor of
            %   rawData_ETG4000
            %
            % obj=rawData_ETG4000(id) creates a new rawData_ETG4000
            %   with the given identifier (id). The name of the
            %   rawData_ETG4000 is initialised
            %   to 'RawDataXXXX' where is the id preceded with 0.
            %

            if (nargin==0)
                %Keep default values
            elseif isa(varargin{1},'rawData_ETG4000')
                obj=varargin{1};
                return;
            else
                obj.id=varargin{1};
                obj.description=['RawData' num2str(obj.id,'%04i')];
            end
            %assertInvariants(obj);

        end
  
    end

    methods (Static)
        coe=table_abscoeff;
    end

end
