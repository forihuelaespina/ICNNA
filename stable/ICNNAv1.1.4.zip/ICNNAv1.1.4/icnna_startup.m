%A setup script...
%
%
% Copyright 2007-2018
% @date: 1-Apr-2007
% @author Felipe Orihuela-Espina
%



%% Log
%
% 25-Apr-2018: FOE. Included scripts/ folder
%
% 30-Oct-2019: FOE.
%   Remove personal folders for cleaner release.
%   Folder separations now use filesep
%



%There's the possibility of adding path directly or use the default
%startup.m file in the MATLAB root directory, but as this is a shared
%computer, I have preferred to do it this way.
mypath=[pwd filesep];

%%Setup path
addpath(mypath);
addpath([mypath 'GUI']);
addpath([mypath 'miscellaneous']);
addpath([mypath 'oo']);
addpath([mypath 'plotting']);
addpath([mypath 'util']);

%Initialize external packages
%WavePath; %WaveLab; installed in \MATLAB\R2011b\toolbox\Wavelab850
    %This package is used to compute the Index of Cognitive Activity in
    %iTrack
cd(mypath);


clear mypath
