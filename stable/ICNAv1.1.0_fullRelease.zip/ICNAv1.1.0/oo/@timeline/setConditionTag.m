function obj=setConditionTag(obj,tag,newTag)
%TIMELINE/SETCONDITIONTAG Set a new tag for a condition
%
% obj=getCondition(obj,tag,newTag) Updates the tag for a condition.
%   If the condition referred by tag has not been defined, a warning
%   is issued and nothing is done.
%
%
% Copyright 2008
% @date: 18-Apr-2008
% @author Felipe Orihuela-Espina
%
% See also getCondition, addCondition, removeCondition, getConditionTag,
% getConditionEvents, setConditionEvents, addConditionEvents,
% removeConditionEvents
%

idx=findCondition(obj,tag);
if (isempty(idx))
    warning('ICNA:timeline:setConditionTag',...
        ['Condition ' tag ' not defined. Ignoring update attempt']);
else
    obj.conditions{idx}.tag=newTag;
end
assertInvariants(obj)