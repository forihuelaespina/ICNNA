function [B]=rgb2hsi(A)
%Convert an RGB image to an HSI image
%
% [B]=rgb2hsi(A) converts an RGB image to an HSI image.
%
%% Colourimetric transformation:
%
% From: http://web2.clarkson.edu/class/image_process/RGB_to_HSI.pdf
%
% First, we convert RGB color space image to HSI space beginning with
% normalizing RGB values:
%
%           R
%   r = -----------
%        R + G + B
%
%           G
%   g = -----------
%        R + G + B
%
%           B
%   b = -----------
%        R + G + B
%
% Then, each normalized H, S and I components are then obtained by
%
%              /      0.5*[(r-g)+(r-b)]    \
%   h = cos^-1 | --------------------------|        h in [0,pi] for b<=g
%              \ sqrt((r-g)^2 + (r-b)(g-b))/
%
%                   /      0.5*[(r-g)+(r-b)]    \
%   h = 2*pi-cos^-1 | --------------------------|   h in [pi,2*pi] for b>g
%                   \ sqrt((r-g)^2 + (r-b)(g-b))/
%
%
%
%   S = 1-3*min(r,g,b);     s in [0,1]
%
%   I = (R+G+B)/3;          i in [0,255]
%
%
% For convenience, h values are converted in the ranges of [0,360]
%
%   H = h*180/pi
%
% 
% Copyright 2010
% @date: 29-Sep-2009
% @author: Felipe Orihuela-Espina
% @modified: 11-May-2010
%
% See also getImageHue
%

r = double(A(:,:,1))./sum(A,3);
g = double(A(:,:,2))./sum(A,3);
b = double(A(:,:,3))./sum(A,3);

tmpNumerator=0.5*((r-g)+(r-b));
tmpDenominator=sqrt((r-g).^2 + (r-b).*(g-b));
h = acos(tmpNumerator./tmpDenominator);
h(b>g) = 2*pi-h(b>g);

B(:,:,1) = round(h*180/pi); %H
B(:,:,2) = 1-3*min(r,min(g,b)); %S
B(:,:,3) = round(sum(A,3)/3); %I


