function obj=setConditionEvents(obj,tag,events)
%TIMELINE/SETCONDITIONEVENTS Set the events for the condition referred by tag
%
% obj=setConditionEvents(obj,tag,events) Sets the events for
%   the experimental condition referred by tag. If the condition
%   has not been defined, a warning is issued and nothing is done.
%   Note that this will remove previously defined events.
%
% Copyright 2008
% @date: 18-Apr-2008
% @author Felipe Orihuela-Espina
%
% See also getCondition, addCondition, removeCondition, setConditionTag,
% getConditionEvents, addConditionEvents, removeConditionEvents
%

idx=findCondition(obj,tag);
if (isempty(idx))
    warning('ICNA:timeline:setConditionEvents:InvalidCondition',...
            ['Condition ' tag ' not defined. Ignoring update attempt']);
else
    if isempty(events)
        obj.conditions{idx}.events=zeros(0,2);
    elseif ((ndims(events)==2) && (size(events,2)==2))
        obj.conditions{idx}.events=sortrows(events);
    else
        error('ICNA:timeline:setConditionEvents:InvalidEvents',...
            'Events must a 2 column (onset duration) matrix.');
    end
end
assertInvariants(obj);