function res=eq(obj,obj2)
%RAWDATA_ETG4000/EQ Compares two objects.
%
% obj1==obj2 Compares two objects.
%
% res=eq(obj1,obj2) Compares two objects.
%
%
% Copyright 2008-10
% @date: 11-Jul-2008
% @author Felipe Orihuela-Espina
% @modified: 21-Jul-2010
%
% See also rawData_ETG4000
%

res=true;
if ~isa(obj2,'rawData_ETG4000')
    res=false;
    return
end

res=eq@rawData(obj,obj2);

res = res && (strcmp(get(obj,'Version'),get(obj2,'Version')));
%Patient information
res = res && (strcmp(get(obj,'SubjectName'),get(obj2,'SubjectName')));
res = res && (strcmp(get(obj,'SubjectSex'),get(obj2,'SubjectSex')));
res = res && all(get(obj,'SubjectAge')==get(obj2,'SubjectAge'));
if ~res
    return
end

%Analysis information (for presentation only)
res = res && (get(obj,'PreTime')==get(obj2,'PreTime'));
res = res && (get(obj,'PostTime')==get(obj2,'PostTime'));
res = res && (get(obj,'RecoveryTime')==get(obj2,'RecoveryTime'));
res = res && (get(obj,'BaseTime')==get(obj2,'BaseTime'));
res = res && (get(obj,'FittingDegree')==get(obj2,'FittingDegree'));
if (ischar(get(obj,'HPF')))
    res = res && (strcmp(get(obj,'HPF'),get(obj2,'HPF')));
else
    res = res && (get(obj,'HPF')==get(obj2,'HPF'));
end
if (ischar(get(obj,'LPF')))
    res = res && (strcmp(get(obj,'LPF'),get(obj2,'LPF')));
else
    res = res && (get(obj,'LPF')==get(obj2,'LPF'));
end
res = res && (get(obj,'MovingAverage')==get(obj2,'MovingAverage'));
if ~res
    return
end


%Measure information
res = res && (all(get(obj,'NominalWavelenghtSet')...
                  ==get(obj2,'NominalWavelenghtSet')));
res = res && (strcmp(get(obj,'ProbeMode'),get(obj2,'ProbeMode')));
res = res && (get(obj,'nChannels')==get(obj2,'nChannels'));
res = res && (get(obj,'SamplingRate')==get(obj2,'SamplingRate'));
res = res && (get(obj,'nBlocks')==get(obj2,'nBlocks'));
if ~res
    return
end

%The data itself!!
res = res && (all(all(get(obj,'LightRawData')==get(obj2,'LightRawData'))));
res = res && (all(all(get(obj,'Marks')==get(obj2,'Marks'))));
res = res && (all(all(get(obj,'Timestamps')==get(obj2,'Timestamps'))));

