function [h]=plotStructuredData(sd,options)
%Display the data in a structuredData
%
% [h]=plotStructuredData(sd,options) Display the data in a structuredData.
%	 See options below
%
%
%% Options
%
%   .mainTitle: The main title of the figure as a string. By default
%       is set to the structuredData Description.
%   
%   .whichSignals - A row vector indicating which signals to plot. By
%   default all signals in the channel will be displayed. If indicated
%   the number elements must correspond with the number of signals
%   in the structured data.
%       length(whichSignals)==get(sd,'NSignals')
%
%   .scale - True if you want all channels to share the same scale
%   (default). False if each channel is to be displayed on a different
%   scale.
%
%   .scaleLimits - [min max] Determine the Y scale limits of the plots.
%   It is only taken into account if option .scale=True. Otherwise
%   they are ignored. When not provided, the function will automatically
%   look for the "best" limits.
%
%   .fontSize - The font size used in the plots. Size 13 points used by
%   default
%
%   .lineWidth - The line width used in the plots. Size 1.5 used by
%   default
%
%   .displayLegend - True (default) if you want ot display the legend.
%
%   .legendLocation - The location of the legend. Default 'NorthEast'.
%
%% Parameters
%
%   sd - A structuredData
%
%   options-  [Optional] A struct of options. See section options
%
%% Output
%
% A figure/axis handle.
%
% Copyright 2008
% Date: 13-Nov-2008
% Author: Felipe Orihuela-Espina
%
% See also structuredData, plotChannel, shadeTimeline
%


if ~isa(sd,'structuredData')
    error('ICNA:plotStructuredData:InvalidInput',...
        'Invalid input parameter.');
end

data=get(sd,'Data');

%% Deal with options
opt.mainTitle=[get(sd,'Description')];
opt.scale=true;
%Calculate an appropriate Y scale (rounding to the nearest decade)
maxY = ceil(max(max(max(real(data))))/10)*10;
minY = floor(min(min(min(real(data))))/10)*10;
opt.scaleLimits=[minY maxY];
opt.fontSize=13;
opt.lineWidth=1.5;
opt.displayLegend=true;
opt.legendLocation='NorthEast';
if(exist('options','var'))
    %%Options provided
    if(isfield(options,'mainTitle'))
        opt.mainTitle=options.mainTitle;
    end
    if(isfield(options,'scale'))
        opt.scale=options.scale;
    end
    if(isfield(options,'scaleLimits'))
        opt.scaleLimits=options.scaleLimits;
    end
    if(isfield(options,'fontSize'))
        opt.fontSize=options.fontSize;
    end
    if(isfield(options,'lineWidth'))
        opt.lineWidth=options.lineWidth;
    end
    if(isfield(options,'displayLegend'))
        opt.displayLegend=options.displayLegend;
    end
    if(isfield(options,'legendLocation'))
        opt.legendLocation=options.legendLocation;
    end
end


%% Initialize the figure
%...and hide the GUI as it is being constructed
screenSize=get(0,'ScreenSize');
wOffset=round(screenSize(3)/10);
hOffset=round(screenSize(4)/10);
width=screenSize(3)-round(screenSize(3)/4);
height=screenSize(4)-round(screenSize(4)/4);
f=figure('Visible','off','Position',[wOffset,hOffset,width,height]);
set(f,'NumberTitle','off');
set(f,'MenuBar','none'); %Hide MATLAB figure menu
%set(f,'CloseRequestFcn',{@OnClose_Callback});
movegui('center');

%% Add components
bgColor=get(f,'Color');

%Main area elements
controlPanel = uipanel(f,...
        'BorderType','none',...
		'FontSize',opt.fontSize-2,...
        'BackgroundColor',get(f,'Color'),...
        'Position',[0.01 0.01 0.2 0.98]);
    

uicontrol(controlPanel,'Style', 'text',...
       'String', 'Show/Hide Signals:',...
       'BackgroundColor',bgColor,...
       'FontSize',opt.fontSize,...
       'HorizontalAlignment','center',...
       'Units','normalize',...
       'Position', [0.05 0.9 0.9 0.1]);
uicontrol(controlPanel,'Style', 'listbox',...
       'Tag','signalsListBox',...
       'String', '0',...
       'Min',0,...
       'Max',2,...
       'BackgroundColor','w',...
       'FontSize',opt.fontSize-2,...
       'HorizontalAlignment','left',...
       'Callback',{@SignalsListBox_Callback},...
       'Units','normalize',...
       'Position', [0.05 0.55 0.9 0.38]);

tabPanel=uitabgroup('v0',f,...
       'Position', [0.22 0.1 0.76 0.8]);

temporalViewTab = uitab('v0',tabPanel,...
       'Title','Temporal View');
%Generate 1 axes per channel on 2 columns
nChannels=get(sd,'NChannels');
nSamples=get(sd,'NSamples');
for ch=1:nChannels
    chAxes(ch)=axes('Parent',temporalViewTab);
    set(chAxes(ch),...
        'Tag',['chAxes' num2str(ch)],...
		'FontSize',opt.fontSize,...
        'Color','w',...
        'YTick',[0],...
        'Units','normalize');

    
    set(get(chAxes(ch),'YLabel'),'String',['Ch.' num2str(ch)])   
    %Set the Y label location
    if ch<=floor(nChannels/2)
        set(chAxes(ch),'YAxis','left');
    else
        set(chAxes(ch),'YAxis','right');
    end
    

    %Set the position (2 columns)
    offsetMargin=0.05;
    height=(1-2*offsetMargin)/(floor(nChannels/2));
    yPos=(1-2*offsetMargin)-(mod(ch-1,(nChannels/2)))*height;
    xPos=0.05;
    if ch>floor(nChannels/2)
        xPos=0.52;
    end
    set(chAxes(ch),'Position',[xPos yPos 0.43 height])
    
    if ((ch==1) || (ch==floor(nChannels/2)+1))
        set(chAxes(ch),'XAxis','top');
    elseif ((ch==nChannels) || (ch==floor(nChannels/2)))
        set(get(chAxes(ch),'XLabel'),'String','Time (samples)'); 
    else
        set(chAxes(ch),'XTick',[]);
    end
    
    set(chAxes(ch),'XLim',[1 nSamples]);
    if(opt.scale)
        set(chAxes(ch),'YLim',opt.scaleLimits);
    end
end


%% On Opening
handles = guihandles(f); %NOTE that only include those whose 'Tag' are not empty
handles.currentElement.data=sd;
handles.chAxes=chAxes;

handles.colormap=[1 0 0; ...
    0 0 1; ...
    0 1 0; ...
    1 1 0; ...
    1 0 1; ...
    0 1 1; ...
    0 0 0];


guidata(f,handles);
OnLoad_Callback(f,[]);

%% Make GUI visible
set(f,'Name','ICNA - plotStructuredData');
set(f,'Visible','on');

%% SignalsListBox Callback
%Show or Hide signals
function SignalsListBox_Callback(hObject,eventData)
% hObject - Handle of the object, e.g., the GUI component,
%   for which the callback was triggered.  See GCBO
% eventdata - Reserved for later use.
refreshTemporalView(hObject);
end

%% OnLoad callback
%Converts data to a structured data and plot the data afresh.
function OnLoad_Callback(hObject,eventData)
% hObject - Handle of the object, e.g., the GUI component,
%   for which the callback was triggered.  See GCBO
% eventdata - Reserved for later use.
handles=guidata(hObject);
sd=handles.currentElement.data;
nSamples=get(sd,'NSamples');
nChannels=get(sd,'NChannels');
nSignals=get(sd,'NSignals');
data=get(sd,'Data');

lineWidth=1.5;

%Controls (By default all signals are shown)
if (nSignals==0)
    set(handles.signalsListBox,'String','');
    set(handles.signalsListBox,'Value',[]);
else
    signalTags=cell(1,nSignals);
    for ii=1:nSignals
        signalTags(ii)={getSignalTag(sd,ii)};
    end
    set(handles.signalsListBox,'String',signalTags);
    set(handles.signalsListBox,'Value',1:nSignals);
end

%Plot the signals
for ch=1:nChannels
    axes(handles.chAxes(ch));
    for ss=1:nSignals
        HH(ch,ss)=line('XData',1:nSamples,...
            'YData',data(:,ch,ss),...
            'LineStyle','-',...
            'LineWidth',lineWidth,...
            'Color',handles.colormap(ss,:));
    end    
    %%Shade the regions of stimulus
    %%%IMPORTANT NOTE: If I try to first paint stimulus regions and
    %%%later the signal, at the moment will not work...
    shadeTimeline(gca,get(sd,'Timeline'));
end
handles.signalHandles=HH;
%if opt.displayLegend
%    legend(legendTags,'Location',opt.legendLocation);
%end

guidata(hObject,handles);
end

%% Refresh temporal view
%Refresh the temporal view
function refreshTemporalView(hObject)
% hObject - Handle of the object, e.g., the GUI component
handles=guidata(hObject);
sd=handles.currentElement.data;

whichSignals=get(handles.signalsListBox,'Value');
nSignals=get(sd,'NSignals');

%%Show or hide the signals
for ch=1:nChannels
    for ss=1:nSignals
        if ismember(ss,whichSignals)
            set(handles.signalHandles(ch,ss),'Visible','on');
        else
            set(handles.signalHandles(ch,ss),'Visible','off');
        end
    end
end

end

end %function
