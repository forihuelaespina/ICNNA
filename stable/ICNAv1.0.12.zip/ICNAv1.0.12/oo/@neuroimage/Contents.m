% @NEUROIMAGE
%
% Files
%   display    - NEUROIMAGE/DISPLAY Command window display
%   eq         - NEUROIMAGE/EQ Compares two objects.
%   neuroimage - Class neuroimage
