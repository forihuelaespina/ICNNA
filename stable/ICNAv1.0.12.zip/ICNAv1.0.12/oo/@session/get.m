function val = get(obj, propName)
% SESSION/GET Get properties from the specified object
%and return the value
%
% val = get(obj, propName) Gets value of the property propName 
%
%% Properties
%
% 'Definition' - Session definition
% 'Date' - Date
% 'Name' - The name as defined in the definition
%
%
% Copyright 2008
% @date: 12-May-2008
% @author Felipe Orihuela-Espina
%
% See also session, set
%

switch propName
case 'Name'
   val = get(obj.definition,'Name');
case 'Definition'
   val = obj.definition;
case 'Date'
   val = obj.date;
otherwise
   error([propName,' is not a valid property'])
end