% @RAWDATA
%
% Files
%   display - RAWDATA/DISPLAY Command window display of a rawData
%   eq      - RAWDATA/EQ Compares two objects.
%   get     - RAWDATA/GET Get properties from the specified object
%   rawData - Abstract Class rawData
%   set     - RAWDATA/SET Set object properties and return the updated object
