function obj=unlock(obj)
% DATASOURCE/UNLOCK Unlocks raw and processed data
%
% obj=lock(obj) Unlocks raw data and processed data.
%
%
% Copyright 2008
% @date: 13-May-2008
% @author Felipe Orihuela-Espina
%
% See also isLock, set, get, lock
%

obj=set(obj,'Lock',false);
