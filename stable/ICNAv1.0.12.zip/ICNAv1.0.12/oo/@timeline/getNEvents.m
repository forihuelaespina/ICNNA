function n=getNEvents(obj, tag)
%TIMELINE/GETNEVENTS Get the number of events defined for the condition
%
% n = getNEvents(obj,tag) Get the number of events defined for the
%   selected condition. If the condition have not been defined
%   then this function returns an empty matrix. Note that
%   although condition may exist there is still the
%   possibility that no events have been defined for this conditions
%   and hence a value 0 will be returned.
%
% Copyright 2008
% @date: 18-Jun-2008
% @author Felipe Orihuela-Espina
%
% See also setConditionEvents, addConditionEvents, removeConditionEvents,
%   getMaxEvents, getTotalEvents
%

idx=findCondition(obj,tag);
n=[];
if (~isempty(idx))
    n=size(obj.conditions{idx}.events,1);
end