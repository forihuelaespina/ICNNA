function [hOxy,hDeoxy,hTotal,hDiff]=plotTopo(sd,stim,mode,options)
%Topographic trepresentation of signals in a nirs_neuroimage
%
% [hOxy,hDeoxy,hTotal,hDiff]=plotTopo(sd,stim,mode)
%   Display the spatial distribution of
%   signals in a nirs_neuroimage, either at a certain instant
%   (sample), averaged across blocks or without block averaging.
%
% [hOxy,hDeoxy,hTotal,hDiff]=plotTopo(sd,stim,mode,options)
%   Display the spatial distribution
%   of signals in a nirs_neuroimage, either at a certain instant
%   (sample), averaged across blocks or without block averaging.
%   See options below
%
%
%% Parameters
%
%   sd - A nirs_neuroimage object
%
%   stim - An stimulus tag or ID, present in the timeline. If mode
%       is numeric, then this parameter will be ignored.
%
%   mode - Either a string or a number/vector.
%       If a string then:
%           + 'AVG' - Block (task only data) averaged mean values
%               are presented.
%           + 'NBA' - Non averaged block (task only data) mean values
%               are presented, leading to 1 figure per block
%       If numeric
%           + a number represents a particular sample (global to
%               the whole timecourse).
%           + a vector represents a set of samples (global to
%               the whole timecourse), of which the mean value
%               is presented.
%
% options - An struct of options
%   .fontSize - Font size to be used in the figure series
%   .destFolder - Destination folder. Default value is
%       './images/'
%   .save - True if you want your figures to be saved. False (default)
%       otherwise. Figures are saved in MATLAB .fig format and in
%       .tif format non-compressed at 300dpi.      
%   .whichBlocks - Evaluate only selected blocks, e.g [2 4] evaluates
%       only blocks [2 and 4].
%       This option is only valid when mode is either 'avg' or 'nba'.
%       Set this field empty, to evaluate all blocks (default).
%
%% Output
%
% hOxy,hDeoxy,hTotal,hDiff - Figure handles for the oxy, deoxy
%   totalHb and HbDiff respectively. Since the 'NBA' mode can lead
%   to several figures, each of these may be an array of handles
%   hOxy(i) is the Oxy topographic map for block i-th.
%       NOTE that if option whichBlocks is used and some blocks
%       are not assessed then hOxy(j) = 0 where j is an unused
%       block.
%
%
% Copyright 2010
% @date: 26-Jul-2010
% @author: Felipe Orihuela-Espina
% @modified: 26-Jul-2010
%
% See also nirs_neuroimage, timeline, structuredData.getBlock,
%   topoOnHead, topoOptodeArray, batchBasicVisualization
%

hOxy=[];
hDeoxy=[];
hTotal=[];
hDiff=[];

        
if ~isa(sd,'nirs_neuroimage')
    error('ICNA:plotTopo:InvalidInputParameter',...
          'nirs_neuroimage object not found.');
end



%% Deal with options
opt.save=false;
opt.destinationFolder='./images/';
%opt.destinationFolder='C:\Felipe\Research\NIRS\Images\GCMC\';
%opt.mainTitle='';
opt.fontSize=13;
opt.whichBlocks=[];
if exist('options','var')
    if isfield(options,'save')
        opt.save=options.save;
    end
    if isfield(options,'destinationFolder')
        opt.destinationFolder=options.destinationFolder;
    end
    if isfield(options,'fontSize')
        opt.fontSize=options.fontSize;
    end
    if isfield(options,'whichBlocks')
        opt.whichBlocks=options.whichBlocks;
    end
end





%% Preparations

t=get(sd,'Timeline');
nChannels = get(sd,'NChannels');
pm =get(sd,'ProbeMode');
switch (pm)
    case '3x3'
        pose=4;
    case '4x4'
        pose=5;
    otherwise
        error('ICNA:plotTopo:InvalidInputParameter',...
            ['Probe Mode ' pm ' not yet available.']);
end

%% Data extraction according to stim and mode
if ischar(mode)

    if ~ischar(stim)
        stim=getConditionTag(t,stim);
        %If the condition does not exist this will get an empty string
        %but we can continue...
    end
    %Check that the stimulus exist
    cevents=getConditionEvents(t,stim);
    %If the condition does not exist this will get an empty matrix

    if isempty(cevents)
        warning('ICNA:plotTopo:NoEventsFound',...
                ['No events found for the selected stimulus. ' ...
                'Stimulus is either missing or does not have ' ...
                'associated events. No plots will be generated.']);
        return;
    end
    
    nBlocks = size(cevents,1);
    blocks = 1:nBlocks;
    if ~isempty(opt.whichBlocks)
    	blocks=opt.whichBlocks;
    end
                
    switch (lower(mode))
        case 'avg'
            blockStr = 'Block = AVG';
            for bb = blocks
                block=getBlock(sd,stim,bb);
                %extract task only data
                tmpt = get(block,'Timeline');
                cevents=getConditionEvents(tmpt,stim);
                    %there should be only one block, i.e. only one event
                tempData = get(block,'Data');
                tempData = tempData(cevents(1):cevents(1)+cevents(2),:,:);
                
                tmpData(:,:,bb) = squeeze(nanmean(tempData));
                %not averaged ACROSS blocks; but still
                %averaged within blocks.
                %Rows are channels, Columns are signals
            end
            data= nanmean(tmpData,3);
            nBlocks = 1;
            blocks = 1;
                %Note that this is how the averaging would be done
                %should I have started from a database, since the
                %average across blocks is computed from the
                %intra-block pre-averaged rows.
            
            idx = find(imag(data));
            data(idx)=NaN;
            %Convert to cell array according to optode arrays
            switch (pm)
                case '3x3'
                    dataOxy(1,1)={data(1:12,nirs_neuroimage.OXY)};
                    dataOxy(1,2)={data(13:nChannels,nirs_neuroimage.OXY)};
                    dataDeoxy(1,1)={data(1:12,nirs_neuroimage.DEOXY)};
                    dataDeoxy(1,2)={data(13:nChannels,nirs_neuroimage.DEOXY)};
                    dataHbT(1,1)={data(1:12,nirs_neuroimage.OXY) ...
                        +data(1:12,nirs_neuroimage.DEOXY)};
                    dataHbT(1,2)={data(13:nChannels,nirs_neuroimage.OXY) ...
                        +data(13:nChannels,nirs_neuroimage.DEOXY)};
                    dataHbDiff(1,1)={data(1:12,nirs_neuroimage.OXY) ...
                        -data(1:12,nirs_neuroimage.DEOXY)};
                    dataHbDiff(1,2)={data(13:nChannels,nirs_neuroimage.OXY) ...
                        -data(13:nChannels,nirs_neuroimage.DEOXY)};
                case '4x4'
                    dataOxy(1,1)={data(1:nChannels,nirs_neuroimage.OXY)};
                    dataDeoxy(1,1)={data(1:nChannels,nirs_neuroimage.DEOXY)};
                    tmp =data(1:nChannels,nirs_neuroimage.OXY) ...
                        +data(1:nChannels,nirs_neuroimage.DEOXY);
                    dataHbT(1,1)={tmp};
                    tmp =data(1:nChannels,nirs_neuroimage.OXY) ...
                        -data(1:nChannels,nirs_neuroimage.DEOXY);
                    dataHbDiff(1,1)={tmp};
                otherwise
                    error('ICNA:plotTopo:InvalidInputParameter',...
                        ['Probe Mode ' pm ' not yet available.']);
            end
            
            
        case 'nba'
            blockStr = '';
            for bb = blocks
                block=getBlock(sd,stim,bb);
                %extract task only data
                tmpt = get(block,'Timeline');
                cevents=getConditionEvents(tmpt,stim);
                    %there should be only one block, i.e. only one event
                tempData = get(block,'Data');
                tempData = tempData(cevents(1):cevents(1)+cevents(2),:,:);

                data = squeeze(nanmean(tempData));
                %not averaged ACROSS blocks; but still
                %averaged within blocks.
                %Rows are channels, Columns are signals
                idx = find(imag(data));
                data(idx)=NaN;
                %Convert to cell array according to optode arrays
                switch (pm)
                    case '3x3'
                        dataOxy(bb,1)={data(1:12,nirs_neuroimage.OXY)};
                        dataOxy(bb,2)={data(13:nChannels,nirs_neuroimage.OXY)};
                        dataDeoxy(bb,1)={data(1:12,nirs_neuroimage.DEOXY)};
                        dataDeoxy(bb,2)={data(13:nChannels,nirs_neuroimage.DEOXY)};
                        dataHbT(bb,1)={data(1:12,nirs_neuroimage.OXY) ...
                            +data(1:12,nirs_neuroimage.DEOXY)};
                        dataHbT(bb,2)={data(13:nChannels,nirs_neuroimage.OXY) ...
                            +data(13:nChannels,nirs_neuroimage.DEOXY)};
                        dataHbDiff(bb,1)={data(1:12,nirs_neuroimage.OXY) ...
                            -data(1:12,nirs_neuroimage.DEOXY)};
                        dataHbDiff(bb,2)={data(13:nChannels,nirs_neuroimage.OXY) ...
                            -data(13:nChannels,nirs_neuroimage.DEOXY)};
                    case '4x4'
                        dataOxy(bb,1)={data(1:nChannels,nirs_neuroimage.OXY)};
                        dataDeoxy(bb,1)={data(1:nChannels,nirs_neuroimage.DEOXY)};
                        tmp =data(1:nChannels,nirs_neuroimage.OXY) ...
                            +data(1:nChannels,nirs_neuroimage.DEOXY);
                        dataHbT(bb,1)={tmp};
                        tmp =data(1:nChannels,nirs_neuroimage.OXY) ...
                            -data(1:nChannels,nirs_neuroimage.DEOXY);
                        dataHbDiff(bb,1)={tmp};
                    otherwise
                        error('ICNA:plotTopo:InvalidInputParameter',...
                            ['Probe Mode ' pm ' not yet available.']);
                end
            end
            
        otherwise
            error('ICNA:plotTopo:InvalidInputParameter',...
                'Unexpected mode.');
    end
    
else %mode is numeric
    l=get(t,'Length');
    if (mode >= l)
        error('ICNA:plotTopo:InvalidInputParameter',...
            ['Mode, when numeric, must be lower or equal than ' ...
            'the nirs_neuroimage length in samples.']);
    end
    
    nBlocks = 1;
    blocks=1;
    if isscalar(mode)
        blockStr = ['Sample = ' num2str(mode)];
        data = getSample(sd,mode); %Rows are channels, Columns are signals
    else %vector
        blockStr = ['Samples = [' num2str(mode(1)) ...
                                  num2str(mode(2:end),',%d') ']'];
        data = get(sd,'Data');
        data = data(mode,:,:);
        data = squeeze(nanmean(data)); %Rows are channels, Columns are signals
    end
        

    idx = find(imag(data));
    data(idx)=NaN;
    %Convert to cell array according to optode arrays
    switch (pm)
        case '3x3'
            dataOxy(1,1)={data(1:12,nirs_neuroimage.OXY)};
            dataOxy(1,2)={data(13:nChannels,nirs_neuroimage.OXY)};
            dataDeoxy(1,1)={data(1:12,nirs_neuroimage.DEOXY)};
            dataDeoxy(1,2)={data(13:nChannels,nirs_neuroimage.DEOXY)};
            dataHbT(1,1)={data(1:12,nirs_neuroimage.OXY) ...
                +data(1:12,nirs_neuroimage.DEOXY)};
            dataHbT(1,2)={data(13:nChannels,nirs_neuroimage.OXY) ...
                +data(13:nChannels,nirs_neuroimage.DEOXY)};
            dataHbDiff(1,1)={data(1:12,nirs_neuroimage.OXY) ...
                -data(1:12,nirs_neuroimage.DEOXY)};
            dataHbDiff(1,2)={data(13:nChannels,nirs_neuroimage.OXY) ...
                -data(13:nChannels,nirs_neuroimage.DEOXY)};
        case '4x4'
            dataOxy(1,1)={data(1:nChannels,nirs_neuroimage.OXY)};
            dataDeoxy(1,1)={data(1:nChannels,nirs_neuroimage.DEOXY)};
            tmp =data(1:nChannels,nirs_neuroimage.OXY) ...
                    +data(1:nChannels,nirs_neuroimage.DEOXY);
            dataHbT(1,1)={tmp};
            tmp =data(1:nChannels,nirs_neuroimage.OXY) ...
                    -data(1:nChannels,nirs_neuroimage.DEOXY);
            dataHbDiff(1,1)={tmp};
        otherwise
            error('ICNA:plotTopo:InvalidInputParameter',...
                ['Probe Mode ' pm ' not yet available.']);
    end
    
end




%% Create the figures (Oxy, deoxy, totalHb and HbDiff)

for bb=blocks
    
    if strcmp(mode,'nba')
        blockStr=['Block = ' num2str(bb)];
    end
        
    
    tmpOptions.mainTitle = [get(sd,'Description') '; ' ...
                blockStr '; HbO_2'];
    [hOxy(bb),~]=topoOnHead(dataOxy(bb,:),pose,tmpOptions);
    clear tmpOptions
    
    if (opt.save)
        outputFilename=['seriesTopo_Oxy'];
        saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
        print(['-f' num2str(gcf)],'-dtiff','-r300',...
            [opt.destinationFolder outputFilename '_300dpi.tif']);
        
        close gcf
    end
    
    tmpOptions.mainTitle = [get(sd,'Description')  '; ' ...
                blockStr '; HHb'];
    [hDeoxy(bb),~]=topoOnHead(dataDeoxy(bb,:),pose,tmpOptions);
    clear tmpOptions
    
    if (opt.save)
        outputFilename=['seriesTopo_Deoxy'];
        saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
        print(['-f' num2str(gcf)],'-dtiff','-r300',...
            [opt.destinationFolder outputFilename '_300dpi.tif']);
        
        close gcf
    end
    
    
    
    tmpOptions.mainTitle = [get(sd,'Description')  '; ' ...
                blockStr '; HbT'];
    [hTotal(bb),~]=topoOnHead(dataHbT(bb,:),pose,tmpOptions);
    clear tmpOptions
    
    if (opt.save)
        outputFilename=['seriesTopo_HbT'];
        saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
        print(['-f' num2str(gcf)],'-dtiff','-r300',...
            [opt.destinationFolder outputFilename '_300dpi.tif']);
        
        close gcf
    end
    
    
    tmpOptions.mainTitle = [get(sd,'Description')  '; ' ...
                blockStr '; HbDiff'];
    [hDiff(bb),~]=topoOnHead(dataHbDiff(bb,:),pose,tmpOptions);
    clear tmpOptions
    
    if (opt.save)
        outputFilename=['seriesTopo_HbDiff'];
        saveas(gcf,[opt.destinationFolder outputFilename '.fig'],'fig');
        print(['-f' num2str(gcf)],'-dtiff','-r300',...
            [opt.destinationFolder outputFilename '_300dpi.tif']);
        
        close gcf
    end
    
end


end