function nimg=convert(obj,varargin)
%RAWDATA_NIRScout/CONVERT Convert raw light intensities to a neuroimage
%
% obj=convert(obj) Convert raw light intensities to a fNIRS
%   neuroimage, using the modified Beer-Lambert law (MBLL).
%
% obj=convert(obj,optionName,optionValue) Convert raw light
%   intensities to a fNIRS neuroimage, using the modified
%   Beer-Lambert law (MBLL) with additional options specified
%   by one or more optionName, optionValue pair arguments.
%
%
% This function performs the modified Beer-Lambert law (MBLL) conversion.
%
% Converts NIRS light intensities to haemoglobin concentration
%changes using the MBLL conversion. This corresponds to solving
%the equation system:
%
%   / Du_a^l1 \   / e_HbO2^?1    e_Hb^l1 \/ DHbO2 \
%   |   ...   | = |    ...         ...   ||  DHHb |    (Eq. 1)
%   \ Du_a^lm /   \ e_HbO2^?m    e_Hb^lm /\       /
%
%   where D() represents variations, u_a^l1 is the macroscopic absorption
% coefficient of the tissue in [mm^-1] measured at wavelength l1 nm,
% and e_HbO2^l1 and e_HHb^l1 represents the specific absorption
% coeffients for oxy- and deoxy- haemoglobin at wavelength l1 in nm.
%
% The macroscopic absorption of the tissue can be calculated
%from the light intensities using the modified Beer Lambert law:
%
%   $$ A  = log_10 \frac{I_0}{I}  = e \cdot c \cdot d \cdot DPF + G $$
%
% where $A$ is the attenuation measured in optical densities,
% $Io$ is the light intensity incident
% on the medium, $I$ is the light intensity transmitted
% through the medium, $e$ is the specific extinction coefficient of the
% absorbing compound measured in $[\mu molar \times cm]$, $c$ is the
% concentration of the absorbing compound in the solution measured
% in $[\mu molar]$, $d$ is the distance between the points where the light
% enters and leaves the medium in $[cm]$ and G is the Geometrical term
% to account for scattering losses.
%
% See below for further discussion.
%
%% The Beer-Lambert law:
% 
%The absorption of light intensity in a non-scattering medium
%is described by the Beer-Lambert Law. This law states that for
%an absorbing compound dissolved in a non-absorbing medium, the
%attenuation ($A$) is proportional to the concentration of the
%compound in the solution ($c$) and the optical pathlength ($d$):
%
%    $ A  = log_10 \frac{I_0}{I}  = e \cdot c \cdot d $$
%
%where A is the attenuation measured in optical densities,
%Io is the light intensity incident on the medium, I is the
%light intensity transmitted through the medium, $e$ is the
%specific extinction coefficient of the absorbing compound
%measured in micromolar per cm, $c$ is the concentration of the
%absorbing compound in the solution measured in micromolar,
%and d is the distance travelled by the photons between the
%points where the light enters and leaves the medium. 
%
%    $ A  = log_10 \frac{I_0}{I}  = e \cdot c \cdot d $$
%
%The product e.c is known as the (macroscopic) absorption
%coefficient of the medium �a.
%
%       $$A = \mu_a \cdot d \iff \frac{A}{\mu_a} = d$$
%   [Okada2003b, pg. 2916]
%   [Sassaroli2004, pg. N256]
%
%% The modified Beer-Lambert law
%
%When a highly scattering medium is considered, the
%Beer-Lambert relationship must be modified to include
%   (i) an additive term, G, due to scattering losses and
%   (ii) a multiplier, to account for the increased optical
%   pathlength due to scattering. The true optical distance
%   is known as the differential pathlength (DP) and the
%   scaling factor as the differential pathlength factor (DPF):
%
%    $$ DP  = DPF \cdot d $$
%
%where $d$ is the geometrical distance. The $DP$ can be approximated
%by the mean distance $L$ [Hiraoka, 1993, pg 1860].
%
% $L$ is the path in the DPF sense or mean path length and
%is calculated as the product of the separation distance
%of probes ($d=3cm$) (i.e. the distance between the optodes,
%or similarly the distance from the light entering point
%to the tissue to the exiting point) multiplied by
%the accepted DPF in normal adult head (6.26 at 807m
%according to Duncan,1995).
%
% $$ DPF=\frac{L}{d} \iff  L=DPF \cdot d $$
%   [Sassaroli, 2004]
%   [Hiraoka, 1993]
%
%$L$ is an approximation to the real DP (differential
%pathlength) [Hiraoka, 1993, pg 1860]. This approximation
%has been criticised:
% According to [Okada2003b, pg. 2921] it is innappropiate
% to use the mean path length L as an alternative to the
% effective path length $DPF\cdot d$ in the activation region.
%
% Using the wrong $DPF(\lambda)$ has the same effect as calculating
%with the wrong chromophore extinction spectra [Kohl,1998, pg. 1772]
%However, for optode distances larger than 2.5cm, the DPF
%is almost wavelength independent [[van der Zee, 1990]
%in Hiraoka, 1993], [[van der Zee, 1990] in Duncan, 1995]. 
%In addition it has been argued that comparing
%MBLL based NIRS signal amplitudes across different
%measurements is not valid unless the partial path length is
%determined [Hoshi, 2005]
%
%
%The modified Beer-Lambert law which incorporates these two
%additions is then expressed as:
%
%   $$ A  = log_10 \frac{I_0}{I}  = e \cdot c \cdot d \cdot DPF + G $$
%
% Since $G$ is unknown, but can be considered constant during
%measurement, taking differences in the above equation:
%
%  $$ (A2-A1)  = (c2-c1) \cdot e \cdot d \cdot DPF $$
%
%Replicating this equation at each different measured wavelength
%results in the system of equation in Eq. 1.
%
% The DPF is adimensional but depends on the wavelength...
%
%% DPF value and Wavelength dependency of the DPF
%
%  The DPF is usually summarised as a simple value.
%In this function, by default a value 6.26 at 807m
%[Duncan, 1995] will be used, but the user can provide
%a different one. For instance, for newborn babies an accepted
%value is $DPF=4.99$ at 807m [Duncan, 1995], for males it might
%be more correct to use 6.09 or for females 6.42.
%[Essenpreis, 1993, pg 421] gets an average $DPF=6.32\pm 0.46$
%at 800 nm for adults.
%
%But the DPF is not really a constant value, but rather
%it depends on the wavelength lambda. In the original fOSA code
%this wavelength dependency is achieved by fixing
%the DPF value to a standard value (e.g. 6.26) and then
%using a wavelength dependent factor, the so called kDPF.
%
%
% $kDPF(\lambda)$ is the correction for the differential pathlength 
%factor, a wavelength dependent factor to correct the accepted
%general $DPF$ value (which comes as wavelength independent).
%
%fOSA 1 reads it from a file call abscoeff
%which has been copied in ICNA to read from
%it as well, and fOSA 2.1 reads it from table_coeff.
%In this sense, you can think of kDPF as:
%
%  $$ DPF(\lambda)=kDPF(\lambda) \cdot DPF_{accepted} $$
%
%To be precise, kDPF does multiply the extinction coefficient
%rather than the DPF in fOSA code, i.e. rather than adapting
%DPF_accepted to a wavelength dependent version, he actually
%leave that as it is, and apply the correction factor to
%something which is already wavelength dependent. See
%[Essenpreis, 1993] for the wavelength dependency of the DPF.
%
%
%% Optical density and Absorbance:
%
% Optical density is the absorbance of an optical element for a given
% wavelength l per unit distance:
%
%  $$ OD = \frac{A}{l} $$
%
% Hence:
%
%  $$ OD = c \cdot e \cdot DPF $$
%
% Please note that sometimes $OD$ is defined exactly the same as
%absorbance i.e. $OD=A$. This is similar to simply considering $l=1$.
%
%
%% Remarks
%
% This function started as a variation from my mbll.m function
%which in turn was derived from fOSA (Koh). However, because of
%the many changes plus more importantly the change in paradigm
%to OOP, it is by now a complete different code (with possibly
%only the line REALLY implementing the MBLL remaining from the
%original fOSA code).
%
%In addition, I have also look at OT-Analysis Kit (Gomez,
% 2006) and Saager kit.
%
%    +========================================+
%    | IMPORTANT                              |
%    +========================================+
%    | Some comments have been literally      |
%    | copied from BORL UCL site              |
%    |                                        |
%    | http://www.medphys.ucl.ac.uk/research/ |
%    |borg/research/NIR_topics/nirs.htm       |
%    | (This webpage no longer exist, and I  |
%    | cannot find the equivalent)            |
%    +========================================+
%
% The coefficients file table_abscoeff are that of fOSA. This file
% is simply a data file, however it has been "implemented" as a
% method. Please, for more information, refer to the method:
%
%   util/table_abscoeff
%
% Currently the separation distance between the optodes
%is fixed to 30 mm.
%
% Unfortunately, it is not easy to estimate DPF for
%short wavelengths and in fact, the file abscoeff does
%not include the kDPF value at 695 nm (which happens to be
%one of the wavelengths at which the NIRS machine works!)
%fOSA simply considers kDPF(l=695)=1 to get around this
%problem, so do I.
%
%% Known bugs
%
% At the moment the code is assuming that light intensities
%are recorded at two wavelengths. However, there may be
%other devices which record more than 2 wavelengths. In
%that case, this code will not work properly.
%
% Please note that the optode "effective" wavelengths at
% the different channels at which the optode is working might
% slightly differ from the "nominal" wavelengths.
% ICNNA does not takes this into account at the moment,
% and considers the nominal waveleghts to be the effective
% wavelengths.
%
%% Parameters
%
% obj - The rawData_NIRScout object to be converted to a nirs_neuroimage
%
% Options - optionName, optionValue pair arguments
%   'AllowOverlappingConditions' - Permit adding conditions to the
%       timeline with an events overlapping behaviour.
%           0 - Overlapping conditions
%           1 - (Default) Non-overlapping conditions
%
%% References
%
% [Duncan, 1995] Duncan, A. et al (1995) "Optical pathlength measurements
% on adult head and the head of the newborn infant using phase
% resolved optical spectroscopy" Physics in Medicine and Biology 40:295-304
%
% [Essenpreis, 1993] Essenpreis, M. et al (1993) "Spectral dependence
%of temporal point spread functions in human tissues" APPLIED OPTICS
%32(4):418-425
%
% [Hiraoka, 1993] Hiraoka, M et al (1993) "A Monte Carlo investigation
%of optical pathlength in inhomogeneous tissue and its application
%to near-infrared spectroscopy" Physics in Medicine and Biology
%38:1859-1876
%
% [Hoshi, 2005] Hoshi, et al (2005) "Reevaluation of near infrared light
%propagation in the adult human head: implications for functional
%near infrared spectroscopy" Journal or Biomedical Optics 10(6):064032
%
% [Kohl, 1998] Kohl, M. et al (1998) "Determination of the wavelength
%dependence of the differential pathlength factor from near
%infrared pulse signals" Physics in Medicine and Biology 43:1771-1782
%
% [Okada, 2003b] Okada and Delpy (2003) "Near-infrared light
%propagation in an adult head model. II. Effect of superficial
%tissue thickness on the sensitivity of the near-infrared
%spectroscopy signal" APPLIED OPTICS 42(16):2915-2922
%
% [Sassaroli, 2004] Sassaroli and Fantini (2004) "Comment on the
% modified Beer-Lambert law for scattering media" Physics in
% Medicine and Biology  49:N255-N257
%
%
%
%
% 
% Copyright 2018
% Copyright over some comments belong to their authors.
% @date: 25-Apr-2018
% @author: Felipe Orihuela-Espina
% @modified: 25-Apr-2018
% 
%
% See also rawData_NIRScout, import, neuroimage, NIRS_neuroimage
%



%% Log
%
% 25-Apr-2018: FOE. Method created
%


opt.allowOverlappingConditions = 1; %Default. Non-overlapping conditions
while ~isempty(varargin) %Note that the object itself is not counted.
    optName = varargin{1};
    if length(varargin)<2
        error('ICNA:rawData_NIRScout:convert:InvalidOption', ...
            ['Option ' optName ': Missing option value.']);
    end
    optValue = varargin{2};
    varargin(1:2)=[];
    
    switch lower(optName)
        case 'allowoverlappingconditions'
            %Check that the value is acceptable
            %   0 - Overlapping conditions
            %   1 - Non-overlapping conditions
            if (optValue==0 || optValue==1)
                opt.allowOverlappingConditions = optValue;
            else
                error('ICNA:rawData_NIRScout:convert:InvalidOption', ...
                     ['Option ' optName ': Unexpected value ' num2str(optValue) '.']);
            end
            
        otherwise
            error('ICNA:rawData_NIRScout:convert:InvalidOption', ...
                  ['Invalid option ' optName '.']);
    end
end


%fprintf('Converting intensities to Hb data ->  0%%');





%   .probesetInfo - An struct holding information about the probe
%       sets and their configuration. The struct has the following fields;
%       .geom - Some standard information about the head and the
%           international 10-20 system
%           |
%           |- NIRxHead - 
%           .   |
%           .   |- ext1020sys 
%           .   .   |
%           .   .   |- coords3d (nPoints x 3)
%           .   .   |
%           .   .   |- labels (1 x 137) with 1|37 being the number of
%           .   .   |       labels of the 10/20 system
%           .   .   |
%           .   .   |- normals (137 x 3)
%           .   .   |
%           .   .   |- center (1 x 3)
%           .   .   |
%           .   .   |- sphere (137 x 3)
%           .   .   |
%           .   .   |- coords2d (137 x 2) - Note that these are NOT a
%           .   .           reduction of the 3D coordinates above. These
%           .   .           seem to be normalized.
%           .   |
%           .   |- mesh - Not all of the following may be defined;
%           .   .   |
%           .   .   |- nodes (nPoints x 4) - Point ID and 3D coordinates
%           .   .   |
%           .   .   |- elems (???? x 5)
%           .   .   |
%           .   .   |- belems (???? x 4)
%           .   .   |
%           .   .   |- fiducials (13 x 4) - Used to generate the affine
%           .   .           transformation matrix for source/detector
%           .   .           registrationsSee NIRSLab User's Manual
%           .   .           v2016.01 (pg.183)
%           .   |
%           .   |- mesh1 - See fields for mesh.
%           .   |
%           .   |- mesh2 - See fields for mesh.
%           .   |
%           .   |- mesh3 - See fields for mesh.
%           |
%           |- xy2dcircle - 
%           .   |
%           .   |- xycircles (??? x 2) -  
%           .   |
%           .   |- xynose (3 x 2) -  
%           .   |
%           .   |- xycross1 (2 x 2) -  
%           .   |
%           .   |- xycross2 (2 x 2) -  
%           .   |
%           .   |- xysquare (5 x 2) -  
%           .   |
%           .   |- xyearL (9 x 2) - Left ear <X,Y> 
%           .   |
%           .   |- xyearR (9 x 2) - Right ear <X,Y> 
%           .
%       .probes - A struct containing channel coordinate values for
%           sources and detectors, both in 2D and 3D spaces.
%           |
%           |- setupType - Scalar
%           |
%           |- nSource0 - Number of sources
%           |
%           |- nDetector0 - Number of detectors
%           |
%           |- nspecify_s - Scalar.
%           |
%           |- normals_s (nSource0 x 3) - Normals of the sources ???
%           |
%           |- coords_s2 (nSource0 x 2) - 2D coordinates of the sources?
%           |
%           |- coords_s3 (nSource0 x 3) - 3D coordinates of the sources?
%           |
%           |- index_s  (nSource0 x 2) - Link to .geom.NIRxHead.nodes? For
%           .               sources
%           |
%           |- nspecify_d - Scalar.
%           |
%           |- normals_d (nSource0 x 3) - Normals of the detectors ???
%           |
%           |- coords_d2 (nSource0 x 2) - 2D coordinates of the detectors?
%           |
%           |- coords_d3 (nSource0 x 3) - 3D coordinates of the detectors?
%           |
%           |- index_d  (nSource0 x 2) - Link to .geom.NIRxHead.nodes? For
%           .               detectors
%           |
%           |- nearDetectors -
%           |
%           |- nearDetectors0 -
%           |
%           |- nChannel0 - Number of configured channels?
%           |
%           |- coords_s2 (nChannel0 x 2) - 2D coordinates of the channels
%           |
%           |- coords_s3 (nChannel0 x 3) - 3D coordinates of the channels
%           |
%           |- index_c  (nChannel0 x 2) - Link to .geom.NIRxHead.nodes? For
%           .               channels
%           |
%           |- normals_c (nChannel0 x 3) - Normals of the channels
%           |
%           |- sourcei0 - Scalar
%           |
%           |- viewType - Scalar. 2 for 2D top? view, or 3 for 3D view.
%           |
%           |- viewangle3 - Azimuth and elevation for the 3D view?
%           .
%       .temphandles - A struct. Not understood.
%       .probeInforFileName - A string with the montage filename
%       .probeInforFilePath - A string with the path to the montage file
%






% %Start by catching the list of imported probe sets. This will
% %be useful at several points during the conversion.
% importedPSidx = [];
% for pp=1:get(obj,'nProbeSets')
%     if obj.probesetInfo(pp).read
%         importedPSidx = [importedPSidx pp];
%     end
% end

%Check if probe information has been defined
if isempty(obj.probesetInfo.probes)
    %Can't do much more, can I? So just return the default neuroimage
    nimg=nirs_neuroimage(1);
    return
end


%assert(length(obj.channelDistances) == obj.probesetInfo.probes.nChannel0, ...
%        'Unexpected number of channel distances');
        


%Some basic initialization
nSamples=size(obj.lightRawData,1);
nSignals=length(obj.wLengths);
nChannels = get(obj,'nChannels');
nWlengths=length(get(obj,'nominalWavelengthSet'));
nimg=nirs_neuroimage(1,[nSamples,nChannels,nSignals]);


dpf=lower('ok');
%dpf=lower('no');
coefficients=table_abscoeff;
%optodeSeparation = 3; %Separation distance between the optodes in [cm]
optodeSeparation = obj.channelDistances; %Per channel separation distance
                        %between the optodes in [cm]

%Check the optode types
%Assume they are all equal and simply get it from the first imported
%probes set
options.dpf = 6.26; %Average DPF accepted value for normal adult head
switch (obj.probesetInfo.probes.setupType)
    case 1
        %Do nothing. Use the default above.
    otherwise
        if strcmp(dpf,'ok')
            warning('ICNA:rawData_NIRScout:convert:InexactDPF',...
                    ['The DPF for probe type ''' ...
                        obj.probesetInfo(pp).type ''' is not currently ' ...
                     'available. The DPF for the ''adult'' probe ' ...
                     'type (6.26) will be used instead.']);
        end
end


%Note that the channels may be spread across different probes sets,
%Thus, temporarily bring them all together in a single matrix.
%Also, take advantage of the loop for collecting the information
%for the channelLocationMap.
tmpLRD = []; %Light raw data
chProbeSets = [];
chOptodeArrays = [];
oaInfo = struct('mode',{},'type',{},...
                'chTopoArrangement',{},...
                'optodesTopoArrangement',{});
pp=1; %P-th probe set. Just 1 in the NIRScout
oa=1; %N-th optode array. Just 1 in the NIRScout
oaInfo(oa).mode = ['NIRScout_' num2str(obj.probesetInfo.probes.setupType)];
oaInfo(oa).type = num2str(obj.probesetInfo.probes.setupType);
tmpChCoords = obj.probesetInfo.probes.coords_c3;
[nRows,nCols]=size(tmpChCoords);
nRows = min(nRows,get(obj,'nChannels'));
oaInfo.chTopoArrangement = nan(get(obj,'nChannels'),nCols);
oaInfo.chTopoArrangement(1:nRows,:) = tmpChCoords(1:nRows,:);

oa_nCh=get(obj,'nChannels'); %size(oaInfo(oa).chTopoArrangement,1);
probeSet_nCh=get(obj,'nChannels');
oaInfo.optodesTopoArrangement = obj.probesetInfo.probes.coords_c2;

chOptodeArrays = [chOptodeArrays; oa*ones(oa_nCh,1)];
chProbeSets = [chProbeSets; pp*ones(probeSet_nCh,1)];
%tmpLRD = [tmpLRD obj.lightRawData(:,1:nWlengths*probeSet_nCh,pp)];
            

    
    
%Allocate some memory
c_oxy = zeros(nSamples,nChannels);
c_deoxy = zeros(nSamples,nChannels);

%% Convert intensities
%wwait=waitbar(0,'Converting intensities->Hb data... 0%');

%Filter only the acquired channels
tmpLRD = get(obj,'LightRawData');
tmpSDKey = get(obj,'SDKey');
tmpSDMask = get(obj,'SDMask');
chIdx = sort(tmpSDKey(find(tmpSDMask)));

%Apply MBLL
M=mbll(tmpLRD(:,chIdx,:));

c_hb=zeros(nSamples,nChannels,2);
c_hb(:,:,nirs_neuroimage.OXY)=M(:,:,1);
c_hb(:,:,nirs_neuroimage.DEOXY)=M(:,:,2);
nimg=set(nimg,'Data',c_hb);

%fprintf('\n');

%Now update the channel location map information
%nimg=set(nimg,'ProbeMode',obj.probeMode); %DEPRECATED CODE
%waitbar(1,wwait,'Updating channel location map...');
%fprintf('Updating channel location map...\n');
clm = get(nimg,'ChannelLocationMap');
clm = setChannelProbeSets(clm,1:nChannels,chProbeSets);
clm = setChannelOptodeArrays(clm,1:nChannels,chOptodeArrays);
clm = setOptodeArraysInfo(clm,1:length(oaInfo),oaInfo);
    %At this point, neither, the channel 3D locations, the stereotactic
    %positions nor the surface positions are known.
    %Neither is known anything about the optodes.
nimg = set(nimg,'ChannelLocationMap',clm);


%% Set signal tags
nimg=setSignalTag(nimg,nirs_neuroimage.OXY,'HbO_2');
nimg=setSignalTag(nimg,nirs_neuroimage.DEOXY,'HHb');

%% Extract the timeline
%waitbar(1,wwait,'Extracting timeline from marks...');
%fprintf('Extracting timeline from marks...\n');

theTimeline=timeline(nSamples);



%  == Markers Information
%   .eventTriggerMarkers: A matrix for recording the event markers
%       received by the digital trigger inputs, with time stamp and
%       frame numbers. Each event is a row that
%       contains 3 numbers;
%         Column 1: Time (in seconds) of trigger event after the scan
%           started.
%         Column 2: Trigger channel identifier, or condition marker.
%           Triggers received on each digital input DIx (where x denotes
%           the trigger channel) on the front panel are encoded as numbers
%           2DI(x-1), e.g. DI1, DI2, and DI3 are encoded as 1, 2, and 8,
%           respectively. The file stores the sum of simultaneously
%           triggered inputs in decimal representation. By using
%           combinations of trigger inputs, as many as 15 conditions
%           can be encoded by NIRScout and NIRSport systems, while
%           NIRScoutX receives up to 255 conditions (8 inputs).
%         Column 3: The number of the scan frame during which the
%           trigger event was received.
%       By default is empty, set to nan(0,3).


tmpMarks=obj.eventTriggerMarkers(:,2);
tmpSamples=obj.eventTriggerMarkers(:,3);

conds=sort(unique(tmpMarks))';
for cc=conds
    tag=num2str(cc);
    idx=find(tmpMarks==cc);
    onsets=tmpSamples(idx(1:2:end));
    endings=tmpSamples(idx(2:2:end));
    if (length(onsets)==length(endings))
        %Do nothing
        %Each onset has its ending defined
    elseif (length(onsets)-1==length(endings))
        %the last onset is unmatched, i.e. the trial should
        %finish by the end of the recording
        warning('ICNA:rawData_NIRScout:convert:MissedTrialEnding',...
                ['Missed end of trial for condition ' tag '. ' ...
                'Setting end of trial to the end of the recording.']);
        endings=[endings; nSamples];
    else
        warning('ICNA:rawData_NIRScout:convert:CorruptCondition',...
                ['Corrupt block/trial definitions for condition ' ...
                tag '. Ignoring block/trial definitions.']);
        onsets=zeros(0,1);
        endings=zeros(0,1);
    end
    durations=endings-onsets;
    stim=[onsets durations];
    tag=num2str(cc);
    try
        theTimeline=addCondition(theTimeline,tag,stim,...
                                opt.allowOverlappingConditions);
    catch
        warning('ICNA:rawData_NIRScout:convert:CorruptCondition',...
                ['Events overlap in exclusory conditions. ' ...
                'Attempting setting non-exclusory conditions.']);
        opt.allowOverlappingConditions=0;
        theTimeline=addCondition(theTimeline,tag,stim,...
                                opt.allowOverlappingConditions);
        
    end
end


%... and now the same with the timestamps
tmpTimestamps=(1:nSamples)*get(obj,'samplingperiod');
theTimeline=set(theTimeline,'Timestamps',tmpTimestamps');

theTimeline=set(theTimeline,'StartTime',get(obj,'Date'));
theTimeline=set(theTimeline,'NominalSamplingRate',get(obj,'SamplingRate'));

nimg=set(nimg,'Timeline',theTimeline);




%close (wwait);
