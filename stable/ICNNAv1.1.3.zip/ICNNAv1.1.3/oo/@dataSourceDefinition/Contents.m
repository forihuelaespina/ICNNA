% @DATASOURCEDEFINITION
%
% Files
%   dataSourceDefinition - A data source definition encapsulates information about a data source
%   display              - DATASOURCEDEFINITION/DISPLAY Command window display
%   eq                   - DATASOURCEDEFINITION/EQ Compares two dataSourceDefinition objects.
%   get                  - DATASOURCEDEFINITION/GET Get properties from the specified object
%   set                  - DATASOURCEDEFINITION/SET Set object properties and return the updated object
