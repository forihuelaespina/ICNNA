function icna
%DEPRECATED. ICNA main menu
%
% icna - Displays ICNA's main menu
%
%
% This function is now DEPRECATED. Use function icnna instead.
%
%
% Copyright 2008-2018
% @date: 6-Oct-2008
% @author Felipe Orihuela-Espina
% @modified: 25-Apr-2018
%
% See also guiAnalysis, guiExperiment, guiExperimentSpace
%



%% Log
%
% 25-Apr-2018: FOE. Deprecated. Substituted for function icnna.
%


warning('ICNNA:GUI:icna',...
        'This function is now deprecated. Please use icnna function instead.');
icnna

end