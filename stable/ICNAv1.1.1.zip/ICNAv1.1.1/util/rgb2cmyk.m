function A=rgb2cmyk(varargin)
%Converts an RGB image to an CMYK image
%
% B=rgb2cmyk(A) Converts the RGB image A (size MxNx3) to an CMYK
%   image B (size MxNx4). B can be saved to a file using MATLAB's
%   function imwrite.
%
% B=rgb2cmyk(filename) Converts the RGB image in filename to an CMYK
%   image B (size MxNx4). B can be saved to a file using MATLAB's
%   function imwrite.
%
% B=rgb2cmyk(...,outfilename) Converts the RGB image
%   to an CMYK image B (size MxNx4) and saves it to file outfilename
%   in tif format (uncompressed, 300 dpi), common for journal
%   publication.
%
% B=rgb2cmyk(...,outfilename,writeOptions) Converts the RGB image
%   to an CMYK image B (size MxNx4) and saves it to file outfilename
%   in tif format (uncompressed) with the indicated options as in imwrite.
%   For instance:
%       rgb2cmyk(...,outfilename,'Compression','lzw','Resolution',600)
%
%
%
% Copyright 2009-2011
% @date: 21-Oct-2009
% @author: Felipe Orihuela-Espina
% @modified: 10-Aug-2011
%
% See also
%

%Read the image
if ischar(varargin{1})
    filename=varargin{1};
    A=imread(filename);
else
    A=varargin{1};
end
varargin(1)=[];

%Convert the image
A=im_rgb2cmyk(A); %see core function below

%Write the image if necessary
if ~isempty(varargin)
    outfilename=varargin{1};
    varargin(1) = [];
    if isempty(varargin)
        imwrite(A,outfilename,'tif',...
            'Compression','none','Resolution',[300 300]);
    else
        imwrite(A,outfilename,'tif',varargin{:});
    end
end


end


%% AUXILIAR FUNCTION

function B=im_rgb2cmyk (A)
% B=im_rgb2cymk(A) Converts the RGB image A (size MxNx3) to an CMYK
%   image B (size MxNx4).
%
%CONVERSION CODE MODIFIED FROM SOURCE:
%http://www.javascripter.net/faq/rgb2cmyk.htm
    
 r=A(:,:,1);
 g=A(:,:,2);
 b=A(:,:,3);
 
 clear A
 
if (any(any(r<0)) || any(any(g<0)) || any(any(b<0)) ...
  || any(any(r>255)) || any(any(g>255)) || any(any(b>255)))
   error ('RGB values must be in the range 0 to 255.');
end

 computedC = 1 - (double(r)/255); %DO NOT REMOVE THE CONVERSION TO DOUBLE
 computedM = 1 - (double(g)/255);
 computedY = 1 - (double(b)/255);
 clear r g b

 minCMY = min(computedC,min(computedM,computedY));
 
 computedC = (computedC - minCMY) ./ (1 - minCMY) ;
 computedM = (computedM - minCMY) ./ (1 - minCMY) ;
 computedY = (computedY - minCMY) ./ (1 - minCMY) ;
 
 
 try 
     %Attemp to operate in double, but may run out of memory
     B(:,:,4) = minCMY; %computedK. Also, allocate memory
                %The scaling by 255 is only necessary because of the
                %conversion to uint8. Conversion to uint8 is not strictly
                %necessary, but saves a hell of a lot of memory...
     B(:,:,1) = computedC;
     B(:,:,2) = computedM;
     B(:,:,3) = computedY;
 catch 
     B(:,:,4) = uint8(minCMY*255); %computedK. Also, allocate memory
                %The scaling by 255 is only necessary because of the
                %conversion to uint8. Conversion to uint8 is not strictly
                %necessary, but saves a hell of a lot of memory...
     B(:,:,1) = uint8(computedC*255);
     B(:,:,2) = uint8(computedM*255);
     B(:,:,3) = uint8(computedY*255);
 end
 
%  %%BLACK / THIS CONVERSION TO BLACK LEADS TO SOME ERRORS...
%  %%BUT THE CONVERSION SEEMS TO WORK WITHOUT IT.
%  idxBlack=find(r==0 & g==0 & b==0);
%  height=size(A,1);
%  width=size(A,2);
%  [idxBlackX,idxBlackY] = ind2sub([height width],idxBlack);
%  B(idxBlackX,idxBlackY,1) = 0;
%  B(idxBlackX,idxBlackY,2) = 0;
%  B(idxBlackX,idxBlackY,3) = 0;
%  B(idxBlackX,idxBlackY,4) = 1;
 
end


