% Writes a gexf file for a network graph (nodes / edges)
% Inputs:
%   filename is the name of the file
%
%   node_list is a matrix with [node id, {x}, {y}, {z}, {color r}, {color g}, {color b}]
%   IF 'Sparse' option THEN edge_list is a sparse matrix [source id, target id, {weight}, {color r}, {color g}, {color b}]
%  IF 
%  
%  {} --> optional
%
% Output:
%      filename is the gexf file (.gexf)
% Example:
%     export
%  
% Copyright (c) 2013, by Javier Andreu-Perez. Imperial College London.
% This code is distributed under the MIT license

function export_to_gexf(varargin)
    sparse=true;
    switch nargin
        case 0
            disp('Not enough inputs given');
            return
        case 1
            disp('Not enough inputs given');
            return
        case 2
            disp('Not enough inputs given');
            return
        case 3
            filename = varargin{1};
            node_list = varargin{2}; 
            sparse_edges = varargin{3};
        case 4
            filename = varargin{1};
            node_list = varargin{2} ;
            if strcmp(filename{3},'Sparse')
                sparse_edges = varargin{4};
                sparse = true;
            elseif strcmp(filename{3},'Adjacency')
                sparse_edges = varargin{4};
                sparse = false;
            end
        otherwise
            disp('Incorrect number of inputs');
    end
            
    
    % create xml document
    docNode = com.mathworks.xml.XMLUtils.createDocument('gexf');
    docRootNode = docNode.getDocumentElement;

    % set xml namespace
    docRootNode.setAttribute('xmlns', 'http://www.gexf.net/1.2draft')
    docRootNode.setAttribute('version', '1.2')
    docRootNode.setAttribute('xmlns:viz', 'http://www.gexf.net/1.2draft/viz')
    docRootNode.setAttribute('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
    docRootNode.setAttribute('xsi:schemaLocation', 'http://www.gexf.net/1.2draft http://www.gexf.net/1.2draft/gexf.xsd')

    % create graph xml node
    graph = docNode.createElement('graph');

    % save nodes with xyz position
    nodes = docNode.createElement('nodes');
    
    for i = 1:size(node_list,1)
        n = docNode.createElement('node');
        n.setAttribute('id', num2str(node_list(i,1)));
        n.setAttribute('label',num2str(node_list(i,1)));
        
        if size(node_list,2)>1
            xyz = docNode.createElement('viz:position');
            xyz.setAttribute('x', num2str(node_list(i,2)));
            xyz.setAttribute('y', num2str(node_list(i,3)));
            xyz.setAttribute('z', num2str(node_list(i,4)));
            n.appendChild(xyz);
        end
        
        if size(node_list,1)>4
            color = docNode.createElement('viz:color');
            color.setAttribute('r', num2str(node_list(i,5)));
            color.setAttribute('g', num2str(node_list(i,6)));
            color.setAttribute('b', num2str(node_list(i,7)));
            n.appendChild(color);
        end
        
        
        nodes.appendChild(n);
    end

    graph.appendChild(nodes);        

    % save edges [source id, target id]
    edges = docNode.createElement('edges');
    
    if sparse
        for i = 1:size(sparse_edges,1)
            e = docNode.createElement('edge');
            e.setAttribute('source',num2str(sparse_edges(i,1)));
            e.setAttribute('target',num2str(sparse_edges(i,2)));
            if size(sparse_edges,2)>2
                e.setAttribute('weight',num2str(sparse_edges(i,3)));
            end
            if  size(sparse_edges,2)>3
                ecolor = docNode.createElement('viz:color');
                ecolor.setAttribute('r', num2str(sparse_edges(i,4)));
                ecolor.setAttribute('g', num2str(sparse_edges(i,5)));
                ecolor.setAttribute('b', num2str(sparse_edges(i,6)));
                e.appendChild(ecolor);
            end
            edges.appendChild(e);
        end
    else    
        %Alternative edge format - Adjacency matrix
        for i = 1:size(sparse_edges,1)
            for j = 1:size(sparse_edges,1)
                if (sparse_edges(i,j) > 0)
                    e = docNode.createElement('edge');
                    e.setAttribute('source',num2str(i));
                    e.setAttribute('target',num2str(j));
                   color_edge edges.appendChild(e);
                end
            end
        end
    end
    
    graph.appendChild(edges);    
    docRootNode.appendChild(graph);
    
    xmlwrite(filename,docNode);
    % type(filename);  % echo result - for debugging
end