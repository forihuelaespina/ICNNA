% @EXPERIMENTSPACE
%
% Files
%   assertInvariants - Ensures the invariants are met
%   compute          - Compute the space with current configuration
%   display          - Command window display
%   experimentSpace  - An experimentSpace converts the experiment data into a suitable
%   get              - DEPRECATED (v1.2). Get properties from the specified object
%   getSubset        - Access to a subset of points in the space
%   set              - DEPRECATED (v1.2). Set object properties and return the updated object
