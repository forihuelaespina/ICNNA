% @RAWDATA_ETG4000
%
% Files
%   convert         - RAWDATA_ETG4000/CONVERT Convert raw light intensities to a neuroimage
%   display         - RAWDATA_ETG4000/DISPLAY Command window display of a rawData_ETG4000
%   eq              - RAWDATA_ETG4000/EQ Compares two objects.
%   get             - RAWDATA_ETG4000/GET DEPRECATED Get properties from the specified object
%   import          - RAWDATA_ETG4000/IMPORT Reads the raw light intensities 
%   rawData_ETG4000 - Class rawData_ETG4000
%   set             - RAWDATA_ETG4000/SET DEPRECATED Set object properties and return the updated object
%   table_abscoeff  - _____________________________________________________________________________________________
