% @CLUSTER
%
% Files
%   cluster - A cluster (or class) simply holds a record of points which
%   display - Command window display of a cluster
%   eq      - Compares two objects.
%   get     - DEPRECATED (v1.2). Get properties from the specified object
%   set     - DEPRECATED (v1.2). Set object properties and return the updated object
