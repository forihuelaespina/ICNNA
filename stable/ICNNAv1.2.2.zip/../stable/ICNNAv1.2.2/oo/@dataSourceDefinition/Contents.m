% @DATASOURCEDEFINITION
%
% Files
%   dataSourceDefinition - A data source definition encapsulates information about a data source
%   display              - Command window display
%   eq                   - Compares two dataSourceDefinition objects.
%   get                  - DEPRECATED (v1.2). Get properties from the specified object
%   set                  - DEPRECATED (v1.2). Set object properties and return the updated object
